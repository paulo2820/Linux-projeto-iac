@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Atribuir Permissão de Grupo para</strong> <strong class="text-primary">Usuário</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-xl-12">
                            <form action="{{ route('user-groups.store') }}" method="POST">
                                @csrf
                                <div class="row mb-3">
                                    <div class="d-flex justify-content-center col-12">
                                        <div class="col-3 text-center">
                                            <label for="id_user">Usuários</label>
                                            <select name="id_user" id="" class="form-control">
                                                <option value=""></option>
                                                @foreach ( $users as $user )
                                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="d-flex justify-content-center col-12">
                                        <div class="col-6">
                                            <ul class="list-group scrollable-list">
                                                <li class="list-group-item">
                                                    @forelse ( $groups as $group )
                                                        <div class="form-group form-check">
                                                            <input name="group[]" type="checkbox" class="form-check-input" id="{{ $group->id }}" value="{{ $group->id }}">
                                                            <label class="form-check-label" for="{{ $group->id }}">{{ $group->name }}</label>
                                                        </div>
                                                    @empty
                                                        <div class="text-center">
                                                            <h3>Não há permissãoes!</h3>
                                                        </div>
                                                    @endforelse
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="d-flex justify-content-center col-12">
                                        @if (verifiedUserPermission('store|UserGroupsController'))
                                            <div class="mr-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-plus mr-1"></i>
                                                    Cadastrar
                                                </button>
                                            </div>
                                        @endif

                                        <div>
                                            <a href="{{route ('users.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
