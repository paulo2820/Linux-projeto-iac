@extends('template.users')
@section('content')
    <section class="vh-100 pt-0">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="container-fluid h-custom">
            <div class="row d-flex justify-content-center align-items-center h-100">
                {{-- <div class="col-md-9 col-lg-6 col-xl-5">
                <img src="{{asset("assets/images/imagem.jpg")}}" class="img-fluid" alt="imagem ilustrativa">
            </div> --}}
                <div class="col-sm-8 col-md-8 col-lg-6 col-xl-4 offset-xl-1 border shadow">
                    <form method="post">
                        {{-- action="{{ route('login.store')}}" --}}
                        @csrf
                        @method('POST')
                        <div class="row mb-5">
                            <div class="d-flex justify-content-center mt-3">
                                <h1>PMK<em class="text-primary">Docs</em></h1>
                            </div>
                            <div class="d-flex justify-content-center border-bottom">
                                <h1>Cadastro</h1>
                            </div>
                        </div>

                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="name">Nome:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="name" name="name" id="name" value="{{ old('name') }}" class="form-control form-control-lg"
                                    placeholder="Informe seu nome" />
                            </div>
                        </div>

                        <!-- Email input -->
                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="email">Endereço de email:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="email" name="email" id="email" value="{{ old('email') }}" class="form-control form-control-lg"
                                    placeholder="Informe seu email" />
                            </div>
                        </div>

                        <!-- Password input -->
                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="password">Senha:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="password" name="password" id="password" class="form-control form-control-lg"
                                    placeholder="Informe sua senha" />
                            </div>
                        </div>

                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="password">Confirmar senha:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="password" name="password_confirmation" id="password_confirmation"
                                    class="form-control form-control-lg" placeholder="Informe sua senha" />
                            </div>
                        </div>


                        <div class="text-center text-lg-start d-flex justify-content-center mb-3">
                            <button type="submit" class="btn btn-primary btn-lg w-25">
                                Cadastrar
                            </button>
                            <a href="{{route('login')}}" class="btn btn-primary btn-lg w-25 ms-3">
                                Voltar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div
            class="d-flex flex-column flex-md-row text-center text-md-start justify-content-center py-4 px-4 px-xl-5 bg-primary">
            <div class="text-white mb-3 mb-md-0">
                Copyright © 2023. All rights reserved.
            </div>
        </div>
    </section>
@endsection
