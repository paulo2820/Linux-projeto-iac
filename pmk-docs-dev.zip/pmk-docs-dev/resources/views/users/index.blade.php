@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4 mb-4 text-center"><strong><em>Usuários e</strong> <strong class="text-primary">Permissões</em></strong></h1>
                </div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            <div class="card">
                <div class="card-body">
                    <div class="row p-3 border-bottom">
                        <div class="d-flex flex-lg-column align-items-lg-center flex-xl-row">
                            @if (verifiedUserPermission('create|UserPermissionsController'))
                                <div class="mb-lg-2 mr-2">
                                    <a href="{{ route('user-permissions.create') }}" class="btn btn-primary">
                                        <i class="fas fa-plus mr-1"></i>
                                        Atribuir para Usuário Permissões
                                    </a>
                                </div>
                            @endif

                            @if (verifiedUserPermission('create|UserGroupsController'))
                                <div class="mb-lg-2 mr-2">
                                    <a href="{{ route('user-groups.create') }}" class="btn btn-primary">
                                        <i class="fas fa-plus mr-1"></i>
                                        Atribuir para Usuário Grupos
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>

                    <livewire:users-table />

                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
