@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-12 text-center"><strong><em>Bem Vindo</strong> <strong class="text-primary">PMK Docs</em></strong></h1>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            <div class="card">
                <div class="card-body text-center">
                    <p>Caso você ainda não tem acesso as funcionalidades, verificar com o Administrador!</p>
                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
