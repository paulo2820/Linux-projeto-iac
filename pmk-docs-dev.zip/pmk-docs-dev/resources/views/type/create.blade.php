@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex ">
                <h1 class="mt-4 mb-4 col-md-12 text-center"><strong><em>Tipos de</strong> <strong class="text-primary">documento</em></strong></h1>
            </div>

            @if ($errors->any())
                <div class="alert alert-danger mt-2">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @isset($mensagemSucesso)
                <div class="row mt-2">
                    <div class="d-flex col-12 alert alert-success justify-content-center">
                        {{ $mensagemSucesso }}
                    </div>
                </div>
            @endisset

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
                            <form action=" {{ route('type.store') }} " method="post">
                                @csrf
                                <div class="row mb-4 justify-content-xl-center">
                                    <div class="col-sm-12 col-md-12 col-xl-7">
                                        <label for="name">Nome do Tipo de Documento</label>
                                        <input name="name" class="form-control" type="text" autofocus>
                                    </div>
                                </div>
                                @if (verifiedUserPermission('store|TypeController'))
                                    <div class="row mb-4">
                                        <div class="col-md-12 d-flex justify-content-center">
                                            <div class="mt-3 mr-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-plus mr-1"></i>
                                                    Cadastrar
                                                </button>
                                            </div>

                                            <div class="mt-3">
                                                <a href="{{route ('projects.index')}}" class="btn btn-primary text-light">
                                                    <i class="fas fa-undo-alt mr-1"></i>
                                                    Voltar
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            </form>
                        </div>

                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6 scrollable-list">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr class="table-success text-center">
                                        <th>Tipo</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                    @foreach ($types as $type)
                                        <tr>
                                            <th class="align-middle">{{ $type->name }}</th>
                                            <th class="align-middle">

                                                <span class="d-flex justify-content-center">
                                                    @if (verifiedUserPermission('edit|TypeController'))
                                                        <a href="{{ route('type.edit', $type->id) }}"
                                                            class="btn btn-primary btn-sm mr-2">
                                                            <i class="fas fa-pen-square"></i>
                                                        </a>
                                                    @endif

                                                    @if (verifiedUserPermission('destroy|TypeController'))
                                                        <button type="button" class="btn btn-sm btn-danger deleteTypeBtn"
                                                            value="{{ $type->id }}|{{ $type->name }}">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>


                                                        <!-- MODAL DELETE -->
                                                        <div id="deleteModal" class="modal fade" tabindex="-1"
                                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <form action="{{ route('type.destroy', ['type' => $type->id])}}"
                                                                        method="post">
                                                                        @csrf
                                                                        @method('DELETE')
                                                                        <div class="modal-header bg-primary text-light">
                                                                            <h5 class="modal-title">Exclusão do Projeto</h5>

                                                                            <button type="button" class="close"
                                                                                data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>

                                                                        <div class="modal-body">
                                                                            <input type="hidden" name="type_delete_id"
                                                                                id="type_id">
                                                                            <div class="d-flex justify-content-center">
                                                                                <h3>Você realmente deseja excluir este Projeto?
                                                                                </h3>
                                                                            </div>
                                                                            <div class="d-flex justify-content-center mt-3">
                                                                                <h3 id="type_name" class="text-danger"></h3>
                                                                            </div>
                                                                        </div>

                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">Cancelar</button>
                                                                            <button type="submit"
                                                                                class="btn btn-primary">Confirmar</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endif
                                                </span>
                                            </th>
                                        </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
