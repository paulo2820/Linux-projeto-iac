
@extends('template.project-index')
@section('content')
    <div class="docs-content">
        <article class="docs-article">
            {{-- <livewire:document-view-version :document="$document" /> --}}
        </article>
    </div>
@endsection
