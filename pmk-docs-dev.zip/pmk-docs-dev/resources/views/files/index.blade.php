@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4 mb-4 text-center"><strong><em>Visualização</strong> <strong class="text-primary">Arquivos</em></strong></h1>
                </div>
            </div>

            @if(!empty($mensagem))
                <div class="alert alert-{{ isset($mensagem['sucess']) ? 'success':'danger' }} text-center mt-3">
                    {{ isset($mensagem['sucess']) ? $mensagem['sucess'] : $mensagem['error'] }}
                </div>
            @endif

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card">
                <div class="card-body">
                    <div class="row p-3 border-bottom">
                        <div class="col-md-12 d-flex">
                            <div>
                                @if (verifiedUserPermission('create|FileController'))
                                    <a href="{{ route('files.create') }}" class="btn btn-primary">
                                        <i class="fas fa-plus mr-1"></i>
                                        Upload
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <livewire:file-table />
                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
