@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-12 text-center"><strong><em>Editar Documento:</strong> <strong class="text-primary"> {{ $document->name }} {{ $document->version }} </em></strong></h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('sub-document.update', ['document' => $document]) }}" method="post">
                        @csrf
                        @method('POST')
                        <div class="form-row">

                            <div class="form-group col-sm-12 col-md-12 col-lg-12 col-xl-4">
                                <label for="name">Editar Nome do Documento</label>
                                <input name="name" class="form-control" type="text" value="{{$document->name}}">
                            </div>

                            <div class="form-group col-sm-12 col-md-6 col-lg-6 col-xl-5">
                                <label for="id_document_versions">Documentação</label>
                                <select name="id_document_versions" class="form-control">
                                    <option value="">Selecione a Documentação</option>
                                    @foreach ( $documents as $doc )
                                        @foreach ( $doc->documentVersions as $documentVersion )
                                            <option value="{{ $documentVersion->id }}"
                                                @if ($documentVersion->id_document == $doc->id) selected @endif>
                                                {{ $doc->name }} - {{$documentVersion->version}} - {{ ($doc->types)->name }}
                                            </option>
                                        @endforeach
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group col-sm-12 col-md-6 col-lg-6 col-xl-3">
                                <label for="type">Tipo do Documento</label>
                                <select name="type" class="form-control">
                                    <option value="">Selecione tipo do Documento</option>
                                    @foreach ( $types as $type )
                                        <option value="{{$type->id}}"
                                            @if ($document->type == $type->id) selected @endif
                                            >{{$type->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <textarea name="description" cols="30" rows="10"> {{$document->description}} </textarea>
                            </div>
                        </div>

                        <div class="row">
                            @if (verifiedUserPermission('update|SubDocumentController'))
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary mt-2 mr-2">
                                    <i class="fas fa-save mr-1"></i>
                                    Salvar
                                </button>

                                <a href="{{ route('sub-document.index') }}" class="btn btn-primary mt-2">
                                    <i class="fas fa-undo-alt"></i>
                                    Voltar
                                </a>
                            </div>
                            @endif
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
@endsection
