<div class="table-responsive">
    <table class="table table-sm shadow text-center">
        <div class="row mb-3">
            <div class="d-flex justify-content-between mt-4">

                {{-- Filtrar Tabela --}}
                <div class="col-xs-5 col-sm-7 col-md-5 col-lg-6 col-xl-3">
                    <label for="">Filtrar Tabela</label>
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Permissão...">
                </div>

                {{-- Filtrar Quantidade --}}
                <div class="col-xs-2 col-sm-4 col-md-3 col-lg-3 col-xl-1">
                    <label for="">Quantidade</label>
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

                {{-- Head da Tabela --}}
                <thead>
                    <tr class="table-success">
                        <th class="text-center">
                            Permissões
                            <span wire:click="sortBy('controller')" style="cursor: pointer;" class="ml-2">
                                <i
                                    class="fas fa-angle-up {{ $sortColumn === 'controller' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i
                                    class="fas fa-angle-down {{ $sortColumn === 'controller' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th>
                            Descrição
                            <span>

                            </span>
                        </th>

                        <th class="text-center">
                            Ações
                        </th>
                    </tr>
                </thead>
                {{-- BODY da Tabela --}}
                <tbody>
                    @forelse ($permissions as $permission)
                        <tr>
                            <td class="text-center">{{ $permission->controller }} - {{ $permission->name }}</td>
                            <td>{{ $permission->description }}</td>
                            <td class="text-center">
                                <span class="d-flex justify-content-center">
                                    @if (verifiedUserPermission('edit|PermissionController'))
                                        <a href="{{ route('permission.edit', ['permission' => $permission->id]) }}"
                                            class="btn btn-primary btn-sm mr-2">
                                            <i class="fas fa-pen-square"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('destroy|PermissionController'))
                                        <button type="button"
                                            class="btn btn-sm btn-danger mr-2 text-light deletePermission"
                                            value="{{ $permission->id }}|{{ $permission->controller }}|{{ $permission->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    @endif

                                    {{-- MODAL Delete - Permission --}}
                                    @if (verifiedUserPermission('destroy|PermissionController'))
                                        <div id="deleteModal" class="modal fade" tabindex="-1"
                                            aria-labelledby="Modal Delete" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <form
                                                        action="{{ route('permission.destroy', ['permission' => $permission->id]) }}"
                                                        method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <div class="modal-header bg-primary text-light">
                                                            <h5 class="modal-title">Exclusão da Permissão</h5>

                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>

                                                        <div class="modal-body">
                                                            <input type="hidden" name="permission_delete_id"
                                                                id="permission_delete_id">
                                                            <div class="d-flex justify-content-center">
                                                                <h4 class="text-center">Você realmente deseja excluir esta
                                                                    Permissão?</h4>
                                                                <br>
                                                            </div>
                                                            <div class="d-flex justify-content-center mt-3">
                                                                <h4 id="permission_name" class="text-danger text-center">
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer d-flex justify-content-center">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancelar</button>
                                                            <button type="submit"
                                                                class="btn btn-primary">Confirmar</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td class="text-center" colspan="4">
                                <h2 class="p-3">Permissões não encontada!</h2>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </div>
        </div>
    </table>
    {{-- Paginate --}}
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $permissions->links() }}
        </div>
    </div>

</div>
