<section class="docs-section shadow mt-3">
    <div class="p-3">

        <!-- Parte de cima do corpo da documentação - Select Versões e Sub Documentos -->
        <div class="row mb-4 d-print-none">
            <div class="col-12 d-flex justify-content-center">
                <div class="col-md-2">
                    <label for="">Versões</label>
                    <select class="form-select" wire:model="documentId" wire:change="filterVersionByDocumentVersion">
                        @foreach ( $documentVersion as $documentVersion)
                            <option value="{{ $documentVersion->version }}"> {{ $documentVersion->version }} </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3 ms-3 me-3">
                    <label for="">Sub Documentos</label>
                    <select id="select-text" class="form-select">
                        <option value=""> Selecione um Sub Documento </option>

                        @if($documentSearch)
                            @foreach ($documentSearch->subDocuments as $subDocument)
                                {{-- @foreach ($document->subDocuments as $subDocument) --}}
                                    <option value="{{ $subDocument->name }}"> {{ $subDocument->name }} </option>
                                {{-- @endforeach --}}
                            @endforeach
                        @endif

                    </select>
                </div>

            </div>
        </div>

        <!-- Parte de baixo (body) da documentação, onde se encontra os titulos, texto e sub documentos -->
        @if($documentSearch)
            {{-- Documento Principal --}}
            @foreach ( $documentSearch->documents as $document )
                <section>
                    {{-- <h1 class="docs-heading"> {!! $document->name !!} {{ $documentSearch->version }} - {!! ($document->types)->name !!}</h1> --}}
                    <h1 class="docs-heading"> {!! $document->name !!} - {!! ($document->types)->name !!}</h1>
                    <p>{{ \Carbon\Carbon::createFromFormat('Y-m-d', $documentSearch->date_document)->format('d/m/Y') }}</p>
                    <p>{!! $documentSearch->description !!}</p>
                </section>
            @endforeach

            {{-- Sub Documentos --}}
            @foreach ($documentSearch->subDocuments as $subDocument)
                <section class="docs-section" id="{!! $subDocument->name  !!}">
                    <h2 class="section-heading"><span class="text-primary">#</span> {!! $subDocument->name  !!} - {!! ($subDocument->types)->name !!}</h2>
                    <p>{!! $subDocument->description !!}</p>
                </section>
            @endforeach
        @endif

    </div>
</section>





