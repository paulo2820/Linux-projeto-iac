<div class="table-responsive">
    <table class="table table-sm shadow text-center">
        <div class="row mb-3">
            <div class="d-flex justify-content-between mt-4">

                {{-- Filtrar Tabela --}}
                <div class="col-xs-5 col-sm-7 col-md-5 col-lg-6 col-xl-3">
                    <label for="">Filtrar Tabela</label>
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Usuário...">
                </div>

                {{-- Filtrar Quantidade --}}
                <div class="col-xs-2 col-sm-4 col-md-3 col-lg-3 col-xl-1">
                    <label for="">Quantidade</label>
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

                {{-- Head da Tabela --}}
                <thead>
                    <tr class="table-success">
                        <th class="text-center">
                            Usuários
                            <span wire:click="sortBy('name')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'name' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th class="text-center">
                            Email
                            <span wire:click="sortBy('email')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'email' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'email' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th class="text-center">
                            Data de Criação
                            <span wire:click="sortBy('created_at')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'created_at' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'created_at' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th class="text-center" wire:click="sortBy('path')">
                            Ações
                        </th>
                    </tr>
                </thead>
                {{-- BODY da Tabela --}}
                <tbody>
                    @forelse ( $users as $user)
                        <tr>
                            <td class="text-center">{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ \Carbon\Carbon::parse($user->created_at)->format('d/m/Y') }}</td>
                            <td class="text-center">
                                <span class="d-flex justify-content-center">
                                    @if (verifiedUserPermission('show|UserPermissionsController'))
                                        <a href="{{ route('user-permissions.show', ['permission' => $user->id]) }}"
                                            class="btn btn-info btn-sm mr-2 text-light mr-2">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('edit|UsersController'))
                                        <a href="{{ route('users.edit', ['user' => $user->id]) }}"
                                            class="btn btn-primary btn-sm mr-2">
                                            <i class="fas fa-pen-square"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('destroy|UsersController'))
                                        <button type="button" class="btn btn-sm btn-danger mr-2 text-light deleteUser" value="{{ $user->id }}|{{ $user->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>

                                    {{-- MODAL Delete - Users --}}
                                    <div id="deleteUser" class="modal fade" tabindex="-1" aria-labelledby="Modal Delete User" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <form action="{{ route('users.destroy', ['user' => $user->id]) }}"
                                                    method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <div class="modal-header bg-primary text-light">
                                                        <h5 class="modal-title">Exclusão da Permissão</h5>

                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">
                                                        <input type="hidden" name="user_delete_id" id="user_delete_id">
                                                        <div class="d-flex justify-content-center">
                                                            <h4 class="text-center">Você realmente deseja excluir esta Permissão?</h4>
                                                            <br>
                                                        </div>
                                                        <div class="d-flex justify-content-center mt-3">
                                                            <h4 id="user_name" class="text-danger text-center"></h4>
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer d-flex justify-content-center">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Cancelar</button>
                                                        <button type="submit" class="btn btn-primary">Confirmar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    @endif
                                </span>
                            </td>
                        </tr>

                    @empty

                        <tr>
                            <td class="text-center" colspan="4">
                                <h2 class="p-3">Permissões não encontada!</h2>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </div>
        </div>
    </table>
    {{-- Paginate --}}
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $users->links() }}
        </div>
    </div>
</div>

