<div class="table-responsive">
    <table class="table table-sm shadow text-center ">
        <div class="row mb-3">
            <div class="d-flex justify-content-between mt-4">

                {{-- Filtrar Tabela --}}
                <div class="col-xs-5 col-sm-7 col-md-5 col-lg-6 col-xl-2">
                    <label for="">Filtrar Tabela</label>
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Projeto...">
                </div>

                {{-- Filtrar Quantidade --}}
                <div class="col-xs-2 col-sm-4 col-md-3 col-lg-3 col-xl-1">
                    <label for="">Quantidade</label>
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

                {{-- Head da Tabela --}}
                <thead>
                    <tr class="table-success">
                        <th>
                            Projetos
                            <span wire:click="sortBy('name')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'name' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th>
                            Descrição
                        </th>

                        <th>
                            Data de Criação
                        </th>

                        <th class="text-center">
                            Ações
                        </th>
                    </tr>
                </thead>
                {{-- BODY da Tabela --}}
                <tbody>
                    @forelse ($projects as $project)
                        <tr>
                            <td class="text-center align-middle"> {{ $project->name }} </td>
                            <td>{!! $project->description !!}</td>
                            <td class="text-center align-middle"> {{ ($project->created_at)->format('d/m/Y') }} </td>
                            <td class="text-center align-middle">
                                <span class="d-flex justify-content-center">

                                    <a href="{{ route('view-document.index', ['projects' => $project->id]) }}" class="btn btn-info btn-sm mr-2">
                                        <i class="fas fa-eye text-light"></i>
                                    </a>

                                    @if (verifiedUserPermission('edit|ProjectController'))
                                        <a href="{{ route('projects.edit', ['projects' => $project->id]) }}"
                                            class="btn btn-primary btn-sm mr-2">
                                            <i class="fas fa-pen-square"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('createPdf|ProjectController'))
                                        <a href="{{ route('projects.pdf', ['projects' => $project->id]) }}"
                                            class="btn btn-secondary btn-sm mr-2">
                                            <i class="far fa-file-pdf"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('destroy|ProjectController'))
                                        <button type="button"
                                            class="btn btn-sm btn-danger mr-2 text-light deleteProjects"
                                            value="{{ $project->id }}|{{ $project->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    @endif

                                    {{-- MODAL Delete - Permission --}}
                                    @if (verifiedUserPermission('destroy|ProjectController'))
                                        <div id="deleteModal" class="modal fade" tabindex="-1"
                                            aria-labelledby="Modal Delete" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <form
                                                        action="{{ route('projects.destroy', ['projects' => $project->id]) }}"
                                                        method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <div class="modal-header bg-primary text-light">
                                                            <h5 class="modal-title">Exclusão do Projeto</h5>

                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>

                                                        <div class="modal-body">
                                                            <input type="hidden" name="project_delete_id"
                                                                id="project_delete_id">
                                                            <div class="d-flex justify-content-center">
                                                                <h4 class="text-center">Você realmente deseja excluir este
                                                                    Projeto?</h4>
                                                                <br>
                                                            </div>
                                                            <div class="d-flex justify-content-center mt-3">
                                                                <h4 id="project_name" class="text-danger text-center">
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer d-flex justify-content-center">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancelar</button>
                                                            <button type="submit"
                                                                class="btn btn-primary">Confirmar</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td class="text-center" colspan="4">
                                <h2 class="p-3">Projeto não encontado!</h2>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </div>
        </div>
    </table>
    {{-- Paginate --}}
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $projects->links() }}
        </div>
    </div>

</div>

