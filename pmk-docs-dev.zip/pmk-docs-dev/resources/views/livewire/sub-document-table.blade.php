<div class="table-responsive">
    <table class="table table-sm shadow ">

        <div class="row mb-3">
            <div class="d-flex justify-content-between">

                <div class="col-sm-7 col-md-5 col-lg-6 col-xl-4">
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Sub Documento...">
                </div>

                <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

            </div>
        </div>

        <thead>
            <tr class="table-success">
                <th class="text-center">
                    Nome do Sub Documento
                    <span wire:click="sortBy('sub_documents.name')" style="cursor: pointer;" class="ml-2">
                        <i class="fas fa-angle-up {{ $sortColumn === 'sub_documents.name' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                        <i class="fas fa-angle-down {{ $sortColumn === 'sub_documents.name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                    </span>
                </th>
                <th class="text-center">
                    Documento Principal
                    <span wire:click="sortBy('documents.name')" style="cursor: pointer;" class="ml-2">
                        <i class="fas fa-angle-up {{ $sortColumn === 'documents.name' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                        <i class="fas fa-angle-down {{ $sortColumn === 'documents.name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                    </span>
                </th>
                <th class="text-center">
                    Versão do Documento
                    <span wire:click="sortBy('document_versions.version')" style="cursor: pointer;" class="ml-2">
                        <i class="fas fa-angle-up {{ $sortColumn === 'document_versions.version' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                        <i class="fas fa-angle-down {{ $sortColumn === 'document_versions.version' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                    </span>
                </th>
                <th class="text-center">
                    Data do Sub Documento
                    <span wire:click="sortBy('sub_documents.date_document')" style="cursor: pointer;" class="ml-2">
                        <i class="fas fa-angle-up {{ $sortColumn === 'sub_documents.date_document' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                        <i class="fas fa-angle-down {{ $sortColumn === 'sub_documents.date_document' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                    </span>
                </th>
                <th class="text-center">Ações</th>
            </tr>
        </thead>
        <tbody>
            @forelse ( $documents as $document )
                <tr>
                    <td class="text-center"> {{ $document->name }} </td>
                    <td class="text-center"> {{ $document->document_name }} </td>
                    <td class="text-center"> {{ $document->version }} </td>
                    <td class="text-center"> {{ \Carbon\Carbon::parse($document->date_document)->format('d/m/Y') }} </td>
                    <td>
                        <span class="d-flex justify-content-center">

                            {{-- <a href="{{ route('view-document.show', ['document' => $document->document_name . '_' . $document->version]) }}"
                                class="btn btn-info btn-sm mr-2 text-light">
                                <i class="fas fa-eye"></i>
                            </a> --}}

                            @if (verifiedUserPermission('edit|SubDocumentController'))
                                <a href="{{ route('sub-document.edit', ['document' => $document->id]) }}"
                                    class="btn btn-primary btn-sm mr-2">
                                    <i class="fas fa-pen-square"></i>
                                </a>
                            @endif

                            @if (verifiedUserPermission('destroy|SubDocumentController'))
                                <button type="button" class="btn btn-sm btn-danger deleteSubDocumentBtn"
                                    value="{{ $document->id }}|{{ $document->name }}">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            @endif
                        </span>
                    </td>
                </tr>

                <!-- MODAL DELETE -->
                @if (verifiedUserPermission('destroy|SubDocumentController'))
                    <div id="deleteModal" class="modal fade" tabindex="-1" aria-labelledby="Modal Delete"
                        aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form action="{{ route('sub-document.destroy', ['document' => $document->id]) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <div class="modal-header bg-primary text-light">
                                        <h5 class="modal-title">Exclusão do Documento</h5>

                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>

                                    <div class="modal-body">
                                        <input type="hidden" name="sub_document_delete_id" id="sub_document_id">
                                        <div class="d-flex justify-content-center">
                                            <h4 class="text-center">Você realmente deseja excluir este Documento?</h4><br>
                                        </div>
                                        <div class="d-flex justify-content-center mt-3">
                                            <h4 id="sub_document_name" class="text-danger text-center"></h4>
                                        </div>
                                    </div>

                                    <div class="modal-footer d-flex justify-content-center">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary">Confirmar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endif

                @empty

                <tr>
                    <td class="text-center" colspan="4">
                        <h2 class="p-3">Sub Documento não encontrado!</h2>
                    </td>
                </tr>

            @endforelse
        </tbody>
    </table>
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $documents->links() }}
        </div>
    </div>
</div>
