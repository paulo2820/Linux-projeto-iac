<div class="table-responsive">
    <table class="table table-sm shadow text-center">
        <div class="row mb-3">
            <div class="d-flex justify-content-between mt-4">

                {{-- Filtrar Tabela --}}
                <div class="col-xs-5 col-md-4 col-sm-6 col-lg-5 col-xl-3">
                    <label for="">Filtrar Tabela</label>
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Grupo...">
                </div>

                {{-- Filtrar Quantidade --}}
                <div class="col-xs-2 col-sm-4 col-md-3 col-sm-3 col-lg-3 col-xl-1">
                    <label for="">Quantidade</label>
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

                {{-- Head da Tabela --}}
                <thead>
                    <tr class="table-success">
                        <th class="text-center">
                            Grupos
                            <span wire:click="sortBy('name')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'name' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>
                        <th class="text-center" wire:click="sortBy('path')">
                            Ações
                        </th>
                    </tr>
                </thead>
                {{-- BODY da Tabela --}}
                <tbody>
                    @forelse ( $groups as $group)
                        <tr>
                            <td class="text-center">{{ $group->name }}</td>
                            <td class="text-center">
                                <span class="d-flex justify-content-center">
                                    @if (verifiedUserPermission('show|GroupPermissionController'))
                                        <a href="{{ route('group-permissions.show', ['groupPermissions' => $group->id]) }}" type="button" class="btn btn-info btn-sm mr-2 text-light showGroupBtn">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('edit|GroupsController'))
                                        <a href="{{ route('groups.edit', ['groups' => $group->id]) }}"
                                            class="btn btn-primary btn-sm mr-2">
                                            <i class="fas fa-pen-square"></i>
                                        </a>
                                    @endif

                                    @if (verifiedUserPermission('destroy|GroupsController'))
                                        <button type="button" class="btn btn-sm btn-danger deleteGroupBtn"
                                            value="{{ $group->id }}|{{ $group->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    @endif
                                </span>
                            </td>
                        </tr>

                        <!-- MODAL DELETE -->
                        @if (verifiedUserPermission('destroy|GroupsController'))
                            <div id="deleteModal" class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <form action="{{ route('groups.destroy', ['groups' => $group->id])}}"
                                            method="post">
                                            @csrf
                                            @method('DELETE')
                                            <div class="modal-header bg-primary text-light">
                                                <h5 class="modal-title">Exclusão do Projeto</h5>

                                                <button type="button" class="close"
                                                    data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div class="modal-body">
                                                <input type="hidden" name="group_delete_id"
                                                    id="group_delete_id">
                                                <div class="d-flex text-center">
                                                    <h3>Você realmente deseja excluir este Grupo?</h3>
                                                </div>
                                                <div class="d-flex justify-content-center mt-3">
                                                    <h3 id="group_name" class="text-danger"></h3>
                                                </div>
                                            </div>

                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Cancelar</button>
                                                <button type="submit"
                                                    class="btn btn-primary">Confirmar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endif

                    @empty

                        <tr>
                            <td class="text-center" colspan="4">
                                <h2 class="p-3">Nenhum Grupo Encontrado!</h2>
                            </td>
                        </tr>

                    @endforelse
                </tbody>
            </div>
        </div>
    </table>

    {{-- Paginate --}}
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $groups->links() }}
        </div>
    </div>

</div>


