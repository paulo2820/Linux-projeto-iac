<div class="table-responsive">
    <table class="table table-sm shadow ">
        <div class="row mb-3">
            <div class="d-flex justify-content-between mt-4">

                {{-- Filtrar Tabela --}}
                <div class="col-xs-5 col-sm-6 col-lg-5 col-xl-3">
                    <label for="">Filtrar Tabela</label>
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Arquivo...">
                </div>

                {{-- Filtrar Quantidade --}}
                <div class="col-xs-2 col-sm-3 col-lg-2 col-xl-1">
                    <label for="">Quantidade</label>
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

                {{-- Head da Tabela --}}
                <thead>
                    <tr class="table-success">
                        <th class="text-center">
                            Arquivo
                            <span wire:click="sortBy('name')" style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'name' && $sortDirection === 'asc' ? '' : 'text-muted' }} "></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'name' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>
                        <th class="text-center" wire:click="sortBy('type')">
                            Tipo do Arquivo
                            <span style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'type' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'type' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>

                        <th class="text-center" wire:click="sortBy('path')">
                            Caminho do Arquivo
                            <span style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'path' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'path' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>
                        <th class="text-center" wire:click="sortBy('created_at')">
                            Data de Criação
                            <span style="cursor: pointer;" class="ml-2">
                                <i class="fas fa-angle-up {{ $sortColumn === 'created_at' && $sortDirection === 'asc' ? '' : 'text-muted' }}"></i>
                                <i class="fas fa-angle-down {{ $sortColumn === 'created_at' && $sortDirection === 'desc' ? '' : 'text-muted' }}"></i>
                            </span>
                        </th>
                        <th class="text-center">
                            Ações
                        </th>
                    </tr>
                </thead>

                {{-- BODY da Tabela --}}
                <tbody>
                    @forelse ( $files as $file )
                        <tr>
                            <td class="text-center"> {{ Str::limit($file->name, 20, '...') }} </td>
                            <td class="text-center"> {{ $file->type }} </td>
                            <td class="text-center"> {{ Str::limit($file->path, 20, '...') }} </td>
                            <td class="text-center"> {{ \Carbon\Carbon::parse($file->created_at)->format('d/m/Y') }} </td>
                            <td>
                                <span class="d-flex justify-content-center">
                                    @if (verifiedUserPermission('create|FileController'))
                                        <button type="button" class="btn btn-warning btn-sm mr-2 text-light copy" value="{{ $file->path }}">
                                            <i class="far fa-clone"></i>
                                        </button>
                                    @endif

                                    @if (verifiedUserPermission('create|FileController'))
                                        <button type="button" class="btn btn-info btn-sm mr-2 text-light preview" value="{{ $file->name }}|{{ $file->path }}">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    @endif

                                    @if (verifiedUserPermission('destroy|FileController'))
                                        <button type="button" class="btn btn-sm btn-danger deleteFile"
                                            value="{{ $file->id }}|{{ $file->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    @endif
                                </span>
                            </td>
                        </tr>

                        {{-- MODAL Preview --}}
                        @if (verifiedUserPermission('create|FileController'))
                            <div id="previewModal" class="modal fade " tabindex="-1" role="dialog" aria-labelledby="Modal Image" aria-hidden="true">
                                <div class="modal-dialog modal-xl" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-light">
                                            <h5 id="image_name" class="modal-title"></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>

                                        <div class="modal-body">
                                            <embed id="pdf-viewer" src="" width="100%" height="800px" type="application/pdf">
                                            {{-- <img id="image_path" class="img-fluid" alt="User Image"> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        {{-- MODAL Delete --}}
                        @if (verifiedUserPermission('create|FileController'))
                            <div id="deleteModal" class="modal fade" tabindex="-1" aria-labelledby="Modal Delete" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <form action="{{ route('files.destroy', ['file' => $file->id]) }}"
                                            method="post">
                                            @csrf
                                            @method('DELETE')
                                            <div class="modal-header bg-primary text-light">
                                                <h5 class="modal-title">Exclusão do Documento</h5>

                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div class="modal-body">
                                                <input type="hidden" name="file_delete_id" id="file_delete_id">
                                                <div class="d-flex justify-content-center">
                                                    <h4 class="text-center">Você realmente deseja excluir este Documento?</h4>
                                                    <br>
                                                </div>
                                                <div class="d-flex justify-content-center mt-3">
                                                    <h4 id="file_name" class="text-danger text-center"></h4>
                                                </div>
                                            </div>

                                            <div class="modal-footer d-flex justify-content-center">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Confirmar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @empty

                        <tr>
                            <td class="text-center" colspan="4">
                                <h2 class="p-3">Arquivo não encontrado!</h2>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </div>
        </div>
    </table>

    {{-- Paginate --}}
    <div class="row">
        <div class="d-flex justify-content-center">
            {{ $files->links() }}
        </div>
    </div>

</div>
