@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 text-center"><strong><em>Editar Documento:</strong> <strong class="text-primary"> {{ $document->name }} </em></strong></h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('document.update', ['document' => $document]) }}" method="post">
                        @csrf
                        @method('POST')

                        <div class="form-row justify-content-center">
                            <div class="form-group col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <label for="name">Nome do Documentoa</label>
                                <input name="name" class="form-control" type="text" value="{{$document->name}}">
                            </div>
                        </div>

                        <div class="form-row justify-content-center">
                            <div class="form-group col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <label for="id_project">Nome do Projeto</label>
                                <select name="id_project" class="form-control">
                                    <option value="">Selecione o nome do Projeto</option>
                                    @foreach ( $projects as $project )
                                        <option value="{{ $project->id }}" @if ($project->id == $document->id_project) selected @endif> {{ $project->name }} </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-row justify-content-center">
                            <div class="form-group col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <label for="type">Tipo do Documento</label>
                                <select name="type" class="form-control">
                                    <option value="">Selecione um tipo de Documento</option>
                                    @foreach ( $types as $type )
                                        <option value="{{$type->id}}" @if ($type->id == $document->type) selected @endif>{{$type->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary mt-2 mr-2">
                                    <i class="fas fa-save mr-1"></i>
                                    Salvar
                                </button>

                                <a href="{{ route('document.create') }}" class="btn btn-primary mt-2">
                                    <i class="fas fa-undo-alt"></i>
                                    Voltar
                                </a>

                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </main>
@endsection
