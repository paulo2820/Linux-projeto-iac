@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Criar Grupo de</strong> <strong class="text-primary">Permissões</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-xl-12">
                            <form action="{{ route('groups.store') }}" method="post">
                                @csrf
                                <div class="d-flex justify-content-center text-center">
                                    <div class="form-group col-md-4 col-xl-3">
                                        <label for="name">Nome do Grupo</label>
                                        <input name="name" class="form-control" type="text" autofocus>
                                    </div>
                                </div>

                                <div class="row justify-content-center mb-4">
                                    <div class="d-flex justify-content-center">

                                        @if (verifiedUserPermission('store|GroupsController'))
                                            <div class="mr-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-plus mr-1"></i>
                                                    Cadastrar
                                                </button>
                                            </div>
                                        @endif
                                        <div>
                                            <a href="{{route ('groups.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
