@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4 mb-4 text-center"><strong><em>Grupos do</strong> <strong class="text-primary">Sistema</em></strong></h1>
                </div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card">
                <div class="card-body">
                    <div class="row p-3 justify-content-center border-bottom flex-sm-column flex-md-row flex-lg-row flex-xl-row">
                        @if (verifiedUserPermission('create|GroupPermissionController'))
                            <div class="mb-sm-2 col-md-4 col-lg-4 col-xl-2">
                                <a href="{{route('groups.create')}}" class="btn btn-primary col-12">
                                    <i class="fas fa-plus mr-1"></i>
                                    Criar Grupo
                                </a>
                            </div>

                            <div class="col-md-6 col-lg-8 col-xl-3">
                                <a href="{{route('group-permissions.create')}}" class="btn btn-primary col-12">
                                    <i class="fas fa-plus mr-1"></i>
                                    Atribuir Permissão para Grupo
                                </a>
                            </div>
                        @endif
                    </div>
                    <livewire:groups-table />
                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
