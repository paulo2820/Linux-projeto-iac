@extends('template.index')
@section('content')

<main>
    <div class="container-fluid px-4">
        <div class="d-flex">
            <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Visualização do</strong> <strong class="text-primary">Grupo: {{$groupPermissions->name}}</em></strong></h1></div>
        </div>

        @isset($mensagemSucesso)
            <div class="alert alert-success text-center mt-3">
                {{ $mensagemSucesso }}
            </div>
        @endisset

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="d-flex col-12 justify-content-center">
                        <div class="col-8 scrollable-list">
                            <table class="table table-sm text-center table-bordered">
                                <thead class="text-light bg-primary">
                                    <tr>
                                        <th colspan="3">Permissões atribuidas do Grupo " {{ $groupPermissions->name }} "</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ( $permissions as $permission )
                                        <tr>
                                            <td>{{ $permission->controller }} - {{ $permission->name }}</td>
                                            <td>{{ $permission->description }}</td>
                                            <td>
                                                @if (verifiedUserPermission('destroy|GroupPermissionController'))
                                                    <span class="d-flex justify-content-center">
                                                        <button type="button" class="btn btn-sm btn-danger deletePermissionGroupBtn" value="{{$permission->id}}|{{$permission->controller}}|{{$permission->name}}">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </span>
                                                @endif
                                            </td>
                                        </tr>

                                        <!-- MODAL DELETE - Permissão de Grupo -->
                                        @if (verifiedUserPermission('destroy|GroupPermissionController'))
                                            <div id="deletePermissionGroupModal" class="modal fade" tabindex="-1" aria-labelledby="Modal Delete"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <form action="{{ route('group-permissions.destroy', ['groupPermissions' => $permission->id]) }}"
                                                            method="post">
                                                            @csrf
                                                            @method('DELETE')
                                                            <div class="modal-header bg-primary text-light">
                                                                <h5 class="modal-title">Exclusão da Permissão</h5>

                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <div class="modal-body">
                                                                <input type="hidden" name="permission_group_delete_id"
                                                                    id="permission_group_id">
                                                                <div class="d-flex justify-content-center">
                                                                    <h4 class="text-center">Você realmente deseja excluir esta Permissão?</h4>
                                                                    <br>
                                                                </div>
                                                                <div class="d-flex justify-content-center mt-3">
                                                                    <h4 id="permission_group_name" class="text-danger text-center"></h4>
                                                                </div>
                                                            </div>

                                                            <div class="modal-footer d-flex justify-content-center">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Cancelar</button>
                                                                <button type="submit" class="btn btn-primary">Confirmar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    @empty

                                    <tr>
                                        <td><h4>Este grupo não possui nenhuma Permissão!</h4></td>
                                    </tr>

                                    @endforelse




                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="d-flex justify-content-center col-12">
                        <a href="{{route ('groups.index')}}" class="btn btn-primary text-light">Voltar</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>

@endsection
