@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Atribuir Permissão para</strong> <strong class="text-primary">Grupo</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-xl-12">
                            <form action="{{ route('group-permissions.store') }}" method="POST">
                                @csrf
                                <div class="row mb-3">
                                    <div class="d-flex justify-content-center">
                                        <div class="col-xl-4 text-center">
                                            <label for="id_group">Grupos</label>
                                            <select name="id_group" id="" class="form-control">
                                                <option value=""></option>
                                                @foreach ( $groups as $group )
                                                    <option value="{{ $group->id }}">{{ $group->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="d-flex justify-content-center">
                                        <div class="col-xl-6">
                                            <ul class="ist-group scrollable-list">
                                                <li class="list-group-item">
                                                    @forelse ( $permissions as $permission )
                                                        <div class="form-group form-check">
                                                            <input name="permission[]" type="checkbox" class="form-check-input" id="{{ $permission->controller }}" value="{{$permission->id}}">
                                                            <label class="form-check-label"> {{ $permission->controller }} - {{ $permission->name}} </label>
                                                        </div>
                                                    @empty
                                                        <div class="text-center">
                                                            <h3>Não há permissãoes!</h3>
                                                        </div>
                                                    @endforelse
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="d-flex justify-content-center col-12">
                                        @if (verifiedUserPermission('store|GroupPermissionController'))
                                            <div class="mr-2">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-plus mr-1"></i>
                                                    Cadastrar
                                                </button>
                                            </div>
                                        @endif

                                        <div>
                                            <a href="{{route ('groups.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
