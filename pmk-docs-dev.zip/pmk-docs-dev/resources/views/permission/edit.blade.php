@extends('template.index')
@section('content')

<main>
    <div class="container-fluid px-4">
        <div class="d-flex">
            <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Editar</strong> <strong class="text-primary">Permissão: {{$permission->controller}} - {{$permission->name}}</em></strong></h1></div>
        </div>

        @isset($mensagemSucesso)
            <div class="alert alert-success text-center mt-3">
                {{ $mensagemSucesso }}
            </div>
        @endisset

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        {{-- Tela Criar Permissões Individuais --}}
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div>
                            <form action="{{ route('permission.update', ['permission' => $permission->id])}}" method="post">
                                @csrf
                                <div class="row mt-3">
                                    <div class="d-flex col-12 justify-content-center text-center">
                                        <div class="form-group col-md-3">
                                            <label for="name">Método</label>
                                            <input name="name" type="text" class="form-control" value="{{$permission->name}}">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="controller">Controller</label>
                                            <input name="controller" type="text" class="form-control" value="{{$permission->controller}}">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex col-12 justify-content-center text-center">
                                        <div class="form-group col-md-6">
                                            <label for="description">Descrição</label>
                                            <input name="description" type="text" class="form-control" value="{{$permission->description}}">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex justify-content-center col-12">

                                        @if (verifiedUserPermission('update|PermissionController'))
                                            <div class="mr-2">
                                                <button class="btn btn-primary">
                                                    <i class="fas fa-save mr-1"></i>
                                                    Salvar
                                                </button>
                                            </div>
                                        @endif

                                        <div>
                                            <a href="{{route ('permission.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

@endsection
