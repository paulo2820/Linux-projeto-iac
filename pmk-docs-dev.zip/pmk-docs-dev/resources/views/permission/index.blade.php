@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4 mb-4 text-center"><strong><em>Permissões do</strong> <strong class="text-primary">Sistema</em></strong></h1>
                </div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            <div class="card">
                <div class="card-body">
                    <div class="row p-3 border-bottom">
                        <div class="col-md-12 d-flex justify-content-sm-center justify-content-md-start ">
                            <div>
                                @if (verifiedUserPermission('create|PermissionController'))
                                    <a href="{{route('permission.create')}}" class="btn btn-primary">
                                        <i class="fas fa-plus mr-1"></i>
                                        Criar Permissões
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <livewire:permission-table />
                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
