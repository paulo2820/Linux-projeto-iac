@extends('template.index')

@section('content')

<main>
    <div class="container-fluid px-4">
        <div class="d-flex">
            <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Criar</strong> <strong class="text-primary">Permissões</em></strong></h1></div>
        </div>

        @isset($mensagemSucesso)
            <div class="alert alert-success text-center mt-3">
                {{ $mensagemSucesso }}
            </div>
        @endisset

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        {{-- Tela Criar Permissões Individuais --}}
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div>
                            <form action="{{ route('permission.store')}}" method="post">
                                @csrf
                                <div class="row mt-3">
                                    <div class="d-flex col-12 justify-content-center text-center">
                                        <div class="form-group col-md-3">
                                            <label for="name">Método</label>
                                            <input name="name" type="text" class="form-control" value="{{ old('name') }}">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="controller">Controller</label>
                                            <input name="controller" type="text" class="form-control" value="{{ old('controller') }}">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex col-12 justify-content-center text-center">
                                        <div class="form-group col-md-6">
                                            <label for="description">Descrição</label>
                                            <input name="description" type="text" class="form-control" value="{{ old('description') }}">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex justify-content-center col-12">

                                        @if (verifiedUserPermission('store|PermissionController'))
                                            <div class="mr-2">
                                                <button class="btn btn-primary">
                                                    <i class="fas fa-plus mr-1"></i>
                                                    Cadastrar
                                                </button>
                                            </div>
                                        @endif

                                        <div>
                                            <a href="{{route ('permission.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt mr-1"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        {{-- Tela de Permissão de Grupo --}}
                        {{-- <div style="display:none;" id="viewPermissionGroup">
                            <form action="{{ route('permission-groups.store') }}" method="POST">
                                @csrf
                                <div class="row mt-3">
                                    <div class="d-flex justify-content-center col-12">
                                        <div class="form-group col-md-3 text-center">
                                            <label for="">Nome do Grupo</label>
                                            <select name="id_group" class="form-control">
                                                <option value=""></option>
                                                @foreach ( $groups as $group )
                                                    <option value="{{ $group->id }}"> {{ $group->name }} </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex justify-content-center col-12 mb-3">
                                        <div class="col-3 text-center">
                                            <label for="">Permissões</label>
                                            <ul class="list-group list-group-light">
                                                @foreach ( $permissions as $permission )
                                                    <li class="list-group-item">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" name="id_permission" value="{{ $permission->id }}" id="{{ $permission->id }}" />
                                                            <label class="form-check-label" for="{{ $permission->id }}">{{ $permission->controller }} - {{ $permission->name }}</label>
                                                        </div>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="d-flex col-md-12 justify-content-center">
                                        <button class="btn btn-primary">Cadastrar</button>
                                    </div>
                                </div>
                            </form>
                        </div> --}}

                    </div>
                </div>
            </div>
        </div>

        {{-- Tela atribuir Permissões --}}
        {{-- <div class="card mb-4" style="display:none;" id="assignPermission">
            <div class="card-body">
                <div class="row border-bottom">
                    <div class="col-12">
                        <div class="row border-bottom">
                            <div class="col-12 text-center">
                                <h3>Atribuir Permissões</h3>
                            </div>
                        </div>

                        <div class="d-flex mt-3 mb-3">
                            <div class="col-md-6 d-flex justify-content-end">
                                <button class="btn btn-primary" id="btnAssignPermission">Atribuir Permissões Individuais</button>
                            </div>
                            <div class="col-md-6 d-flex justify-content-start">
                                <button class="btn btn-primary" id="btnAssignPermissionGroup">Atribuir Permissões de Grupo</button>
                            </div>
                        </div>
                    </div>
                </div>


                <div style="display:none;" id="viewAssignPermission">
                    <form action="{{ route('user-permissions.store') }}" method="POST">
                        @csrf
                        <div class="row mt-3" >
                            <div class="d-flex col-12 justify-content-center text-center">
                                <div class="form-group col-md-3">
                                    <label for="">Usuário</label>
                                    <select name="id_user" class="form-control">
                                        <option value=""></option>
                                        @foreach ( $users as $user )
                                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="d-flex justify-content-center col-12">
                                <div class="col-8 ">
                                    <table class="table table-bordered">
                                        <thead class="bg-primary text-light text-center">
                                            <tr>
                                                <th>Permissões Individuais</th>
                                                <th>Descrição</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ( $permissions as $permission )
                                                <tr>
                                                    <td class="w-50 align-middle">
                                                        <div class="form-check">
                                                            <input type="checkbox" class="form-check-input" name="id_permission" value="{{ $permission->id }}">
                                                            <label class="form-check-label">{{ $permission->controller }} - {{ $permission->name }}</label>
                                                        </div>
                                                    </td>
                                                    <td class="text-center">
                                                        <div>
                                                            <span>{{ $permission->description }}</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="d-flex col-md-12 justify-content-center mb-3">
                                <button class="btn btn-primary">Cadastrar</button>
                            </div>
                        </div>
                    </form>
                </div>


                <div style="display:none;" id="viewAssignPermissionGroup">
                    <form action="{{ route('user-groups.store') }}" method="post">
                        @csrf
                        <div class="mb-3">
                            <div class="d-flex align-items-center justify-content-center mt-3">
                                <div class="form-group col-3 text-center">
                                    <label for="id_user">Usuário</label>
                                    <select name="id_user" class="form-control form-control-lg">
                                        <option value=""></option>
                                        @foreach ( $users as $user )
                                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="d-flex col-12 justify-content-center">
                                <div class="col-6">
                                    <table class="table table-bordered text-center">
                                        <thead class="bg-primary text-light">
                                            <tr>
                                                <th>Permissões de Grupo</th>
                                            </tr>
                                        </thead>
                                        <tbody >
                                            @foreach ( $groups as $group )
                                                <tr>
                                                    <td>
                                                        <div class="form-check form-check-inline w-25">
                                                            <input class="form-check-input" type="checkbox" name="id_group[]" value="{{ $group->id }}">
                                                            <label class="form-check-label" for="id_group">{{ $group->name }}</label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary mb-3">Cadastrar</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div> --}}
    </div>
</main>

@endsection
