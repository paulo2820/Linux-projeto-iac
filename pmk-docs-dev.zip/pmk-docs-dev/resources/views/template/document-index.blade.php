<!DOCTYPE html>
<html lang="pt-br">
<head>
    @include('template.document-head')
</head>

<body class="docs-page">

    <header class="header fixed-top d-print-none">
        @include('template.document-navbar')
        @livewireStyles
    </header>

    <div class="docs-wrapper">
        @include('template.document-sidebar')
        @yield('content')
    </div>

    @include('template.document-scripts')
    @livewireScripts
</body>
