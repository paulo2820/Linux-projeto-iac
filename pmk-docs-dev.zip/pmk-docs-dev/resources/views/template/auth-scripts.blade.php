<!-- Javascript -->
<script src="{{ asset("assets/plugins/popper.min.js") }}"></script>
<script src="{{ asset("assets/plugins/bootstrap/js/bootstrap.min.js") }}"></script>

<!-- Page Specific JS -->
<script src="{{ asset("assets/plugins/smoothscroll.min.js") }}"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.8/highlight.min.js"></script>

<script src="{{ asset("assets/js/highlight-custom.js") }}"></script>
<script src="{{ asset("assets/plugins/simplelightbox/simple-lightbox.min.js") }}"></script>
<script src="{{ asset("assets/plugins/gumshoe/gumshoe.polyfills.min.js") }}"></script>
<script src="{{ asset("assets/js/docs.js") }}"></script>
