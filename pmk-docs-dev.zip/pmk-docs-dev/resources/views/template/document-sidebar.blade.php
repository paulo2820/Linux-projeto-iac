{{-- @dd(version(12)) --}}

{{-- @php
    info($document)
@endphp --}}

{{-- {{ dd(get_defined_vars()) }} --}}

<div id="docs-sidebar" class="docs-sidebar shadow">
    <nav id="docs-nav" class="docs-nav navbar">
        <ul class="section-items list-unstyled nav flex-column">

            @foreach (allDocumentsProject($projects) as $document)
                <li class="nav-item section-title">
                    <a href="{{ route('view-document.show', ['document' => $document->id])}}" class="nav-link @if (request()->is('view-document/' . $document->id)) active @endif" >
                        <span class="theme-icon-holder ">
                            #
                        </span>
                        {!! $document->name !!}
                    </a>
                </li>
            @endforeach

            <div class="mt-2">
                <a href="{{route('dashboard')}}" class="btn btn-primary btn-sm">
                    <i class="fas fa-undo-alt"></i>
                    VOLTAR
                </a>
            </div>

        </ul>
    </nav>
</div>
