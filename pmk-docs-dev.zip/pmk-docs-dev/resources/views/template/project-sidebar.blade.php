{{-- @dd(version(12)) --}}

{{-- @php
    info($document)
@endphp --}}

{{-- {{ dd(get_defined_vars()) }} --}}

<div id="docs-sidebar" class="docs-sidebar shadow">
    <nav id="docs-nav" class="docs-nav navbar">
        <ul class="section-items list-unstyled nav flex-column">
            {{-- Pelo id do document project, retorna os documentos daquele projeto --}}
            @dd(allDocumentsProject($projects->id))
            @foreach (allDocumentsProject($projects->id) as $document)
                @foreach ( $document->documents as $documents)
                    <li class="nav-item section-title">
                        <a href="{{ route('view-document.show', ['document' => $documents->name . "_" . $document->max_version]
                        )}}" class="nav-link">
                            <span class="theme-icon-holder ">
                                #
                            </span>
                            {!! $documents->name !!}
                        </a>
                    </li>
                @endforeach
            @endforeach

            <div class="mt-2">
                <a href="{{route('projects.index')}}" class="btn btn-primary">VOLTAR</a>
            </div>

        </ul>
    </nav>
</div>

