<!DOCTYPE html>
<html lang="pt-br">
<head>
    @include('template.head')
    @livewireStyles
</head>
<body class="sb-nav-fixed">

    @include('template.navbar')

    <div id="layoutSidenav">
        @include('template.sidebar')

        <div id="layoutSidenav_content">
            @yield('content')
            @include('template.footer')
        </div>
    </div>
    @include('template.scripts')
</body>
