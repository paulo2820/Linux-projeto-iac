<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-light shadow " id="sidenavAccordion">
        <div class="sb-sidenav-menu border-right">
            <div class="nav">
                {{-- <div class="sb-sidenav-menu-heading text-primary">
                    Visualizar Documentação
                </div> --}}

                {{-- <a href="{{ route('view-document.index') }}" class="nav-link border-bottom">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-eye size-icon"></i>
                    </div>
                    <span>Documentação Geral</span>
                </a> --}}

                <div class="sb-sidenav-menu-heading text-primary">
                    Documentos
                </div>

                @if (verifiedUserPermission('index|ProjectController'))
                    <a href="{{ route('projects.index') }}" class="nav-link @if (request()->is('admin/projects')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-alt size-icon"></i>
                        </div>
                        <span>Projeto<span>
                    </a>
                @endif

                @if (verifiedUserPermission('create|DocumentController'))
                    <a href="{{ route('document.create') }}" class="nav-link @if (request()->is('admin/document/create')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-alt size-icon"></i>
                        </div>
                        <span>Criar documento<span>
                    </a>
                @endif

                @if (verifiedUserPermission('index|DocumentVersionController'))
                    <a href=" {{ route('document-version.create') }} " class="nav-link @if (request()->is('admin/document-version/create')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-signature size-icon"></i>
                        </div>
                        <span>Documentar<span>
                    </a>
                @endif

                @if (verifiedUserPermission('index|DocumentVersionController'))
                    <a href="{{ route('document-version.index') }}" class="nav-link @if (request()->is('admin/document-version')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-eye size-icon"></i>
                        </div>
                        <span>Visualizar documentos<span>
                    </a>
                @endif

                @if (verifiedUserPermission('create|TypeController'))
                    <a href="{{ route('type.create') }}" class="nav-link @if (request()->is('admin/type/create')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-alt size-icon"></i>
                        </div>
                        <span>Tipos de documento</span>
                    </a>
                @endif

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Sub Documentos
                </div>

                @if (verifiedUserPermission('create|SubDocumentController'))
                    <a href="{{ route('sub-document.create') }}" class="nav-link @if (request()->is('admin/sub-document/create')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-signature size-icon"></i>
                        </div>
                        <span>Sub documento<span>
                    </a>
                @endif

                @if (verifiedUserPermission('index|SubDocumentController'))
                    <a href="{{ route('sub-document.index') }}" class="nav-link @if (request()->is('admin/sub-document')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-eye size-icon"></i>
                        </div>
                        <span>Visualizar sub documentos<span>
                    </a>
                @endif

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Uploud de Arquivos
                </div>

                @if (verifiedUserPermission('index|FileController'))
                    <a href="{{ route('files.index') }}" class="nav-link @if (request()->is('admin/files')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-file-export size-icon"></i>
                        </div>
                        <span>Arquivos<span>
                    </a>
                @endif

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Permissões Gerais
                </div>

                @if (verifiedUserPermission('index|PermissionController'))
                    <a href="{{ route('permission.index') }}" class="nav-link @if (request()->is('admin/permission')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-cog size-icon"></i>
                        </div>
                        <span>Permissões<span>
                    </a>
                @endif

                @if (verifiedUserPermission('index|GroupsController'))
                    <a href="{{ route('groups.index') }}" class="nav-link @if (request()->is('admin/groups')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-users size-icon"></i>
                        </div>
                        <span>Grupos<span>
                    </a>
                @endif

                @if (verifiedUserPermission('index|UsersController'))
                    <a href="{{ route('users.index') }}" class="nav-link @if (request()->is('admin/user')) active @endif">
                        <div class="sb-nav-link-icon d-flex align-items-center">
                            <i class="fas fa-address-book size-icon"></i>
                        </div>
                        <span>Usuários<span>
                    </a>
                @endif
            </div>
        </div>

        <div class="sb-sidenav-footer border-right">
            <div class="small">Usuário Logado:</div>
            {{auth()->user()->name}}
        </div>
    </nav>
</div>
