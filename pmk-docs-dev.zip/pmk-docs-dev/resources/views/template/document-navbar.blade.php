<header class="header fixed-top">
    <div class="branding docs-branding shadow bg-document-nav">
        <div class="container-fluid position-relative py-2">
            <div class="docs-logo-wrapper">
                <button id="docs-sidebar-toggler" class="docs-sidebar-toggler docs-sidebar-visible me-2 d-xl-none"
                    type="button">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="site-logo"><a class="navbar-brand" href=""><img class="logo-icon me-2"
                    src="{{ asset('assets/images/coderdocs-logo.svg') }}" alt="logo"><span
                    class="logo-text">PMK<span class="text-alt">Docs</span></span></a>
                </div>

            </div>

        </div>
    </div>
</header>
