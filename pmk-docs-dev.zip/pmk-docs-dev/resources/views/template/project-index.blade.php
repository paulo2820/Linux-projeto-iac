<!DOCTYPE html>
<html lang="pt-br">
<head>
    @include('template.project-head')
</head>

<body class="docs-page">
    <header class="header fixed-top d-print-none">
        @include('template.project-navbar')
        @livewireStyles
    </header>

    <div class="docs-wrapper">
        @include('template.project-sidebar')
        @yield('content')
    </div>

    @include('template.project-scripts')
    @livewireScripts
</body>
