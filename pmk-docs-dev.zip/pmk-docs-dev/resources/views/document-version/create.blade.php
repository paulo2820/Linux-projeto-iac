@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-sm-12 col-md-12 col-xl-12 text-center"><h1 class="mt-4 mb-4"><strong><em></strong> <strong class="text-primary">Documentar</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success justify-content-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-12">
                            <form action="{{ route('document-version.store') }}" method="post">
                                @csrf
                                <div class="form-row align-items-center">

                                    <div class="form-group col-md-12 col-xl-3">
                                        <label for="id_document">Documento</label>
                                        <select name="id_document" class="form-control">
                                            <option value="">Selecione o Documento</option>
                                            @foreach ( $id_documents as $id_document )
                                                <option value="{{ $id_document->id }}" @if (old('id_document') == $id_document->id) selected @endif > {{ $id_document->name }} - {{ ($id_document->types)->name }} </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-sm-6 col-md-6 col-xl-2">
                                        <label for="version">Informar Versão</label>
                                        <input name="version" type="text" value="{{ old('version') }}" class="form-control">
                                    </div>

                                    <div class="form-group col-sm-6 col-xl-2">
                                        <label for="date">Data</label>
                                        <input type="date" class="form-control" id="date_document" name="date_document">
                                    </div>

                                    {{-- <div class="form-group col-md-4 d-flex justify-content-end mt-3">
                                        <div>
                                            <button type="submit" class="btn btn-primary btn-lg mt-4" name="duplicar" >Duplicar</button>
                                        </div>
                                    </div> --}}
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <textarea name="description" cols="30" rows="10"> {{ old('description') }} </textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <div class="mt-3 mr-2">
                                            <button type="submit" class="btn btn-primary" name="cadastrar">
                                                <i class="fas fa-plus mr-1"></i>
                                                Cadastrar
                                            </button>
                                        </div>

                                        <div class="mt-3">
                                            <a href="{{route ('projects.index')}}" class="btn btn-primary text-light">
                                                <i class="fas fa-undo-alt mr-1"></i>
                                                Voltar
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection

{{-- <div class="form-group col-md-2">
    <label for="version">Versão</label>
    <input type="text" class="form-control form-control-lg">
</div>

<div class="row">
    <div class="col-md-12">
        <textarea name="description" cols="30" rows="10"></textarea>
    </div>
</div> --}}
