@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-sm-12 col-md-12 text-center"><strong><em>Editar Documento:</strong> <strong class="text-primary">{{$name[0]}} {{$document->version}}</em></strong></h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('document-version.update', ['document' => $document]) }}" method="post">
                        @csrf
                        @method('POST')
                        <div class="form-row">
                            <div class="form-group col-sm-6 col-md-4 col-lg-5 col-xl-2">
                                <label for="version">Versão do Documento</label>
                                <input name="version" class="form-control" type="text" value="{{$document->version}}">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <textarea name="description" cols="30" rows="10">{{$document->description}}</textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save mr-1"></i>
                                        Salvar
                                    </button>
                                </div>
                                <div class="mt-3 ml-2">
                                    <a href="{{ route('document-version.index') }}" class="btn btn-primary">
                                        <i class="fas fa-undo-alt"></i>
                                        Voltar
                                    </a>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </main>
@endsection
