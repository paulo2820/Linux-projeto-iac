<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\{
    DashboardController,
    SubDocumentController,
    DocumentController,
    DocumentVersionController,
    FileController,
    GroupPermissionController,
    GroupsController,
    PermissionController,
    PermissionsController,
    ProjectController,
    TypeController,
    UserGroupsController,
    UserPermissionsController,

};

use App\Http\Controllers\LoginController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\ViewDocumentController;

# ----------------------- Rota - INICIAL (DASHBOARD) ----------------------- #
Route::get('/',  function () {
    return redirect()->route('document-version.index');
});

# ----------------------- Rota - LOGIN ----------------------- #
Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.store');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

# ----------------------- Rota - USERS ----------------------- #
Route::get('/register', [UsersController::class, 'create'])->name('users.create');
Route::post('/register',[UsersController::class, 'store'])->name('users.store');



Route::group(['prefix' => 'admin', 'middleware' => ['login', 'permission']], function() {
    // ->middleware('permission')
    // , 'permission'
    # ROTAS USUARIO
    Route::get('/user', [UsersController::class, 'index'])->name('users.index');
    Route::get('/{user}/edit', [UsersController::class, 'edit'])->name('users.edit');
    Route::post('/{user}/update', [UsersController::class ,'update'])->name('users.update');
    Route::delete('/destroy/{user}',[UsersController::class, 'destroy'])->name('users.destroy');

    # ----------------------- Rota Dashboard ----------------------- #
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    # ----------------------- Rotas - DOCUMENTOS ----------------------- #
    Route::prefix('document')->controller(DocumentController::class)->group(function(){
        // Route::get('/', 'index')->name('document.index');
        Route::get('/create', 'create')->name('document.create');
        Route::post('/document', 'store')->name('document.store');
        Route::get('/{document}/edit', 'edit')->name('document.edit');
        Route::post('/{document}/update', 'update')->name('document.update');
        Route::get('/{document}', 'show')->name('document.show');
        Route::delete('/destroy/{document}', 'destroy')->name('document.destroy');
    });

    # ----------------------- Rotas - DOCUMENTOS VERSION ----------------------- #
    Route::prefix('document-version')->controller(DocumentVersionController::class)->group(function() {
        Route::get('/', 'index')->name('document-version.index');
        Route::get('/create', 'create')->name('document-version.create');
        Route::post('/document-version', 'store')->name('document-version.store');
        Route::get('/{document}/edit', 'edit')->name('document-version.edit');
        Route::post('/{document}/update', 'update')->name('document-version.update');
        // Route::get('/{document}', 'show')->name('document-version.show');
        Route::delete('/destroy/{document}', 'destroy')->name('document-version.destroy');
        // Edita duplicate
        Route::get('/{document}/edit-duplicate', 'editDuplicate')->name('document-version.edit-duplicate');
        // Cria duplicate
        Route::post('/{id_document_version}/create-duplicate', 'storeDuplicate')->name('document-version.store-duplicate');
        // Cria um PDF
        Route::get('/{document}/create-pdf', 'createPdf')->name('document-version.pdf');
    });

    # ----------------------- Rotas - TIPOS DE DOCUMENTOS ----------------------- #
    Route::prefix('type')->controller(TypeController::class)->group(function(){
        Route::get('/create', 'create')->name('type.create');
        Route::post('/type', 'store')->name('type.store');
        Route::get('/{type}/edit', 'edit')->name('type.edit');
        Route::post('/{type}/update', 'update')->name('type.update');
        Route::delete('/destroy/{type}', 'destroy')->name('type.destroy');
    });

    # ----------------------- Rotas - SUB DOCUMENTOS ----------------------- #
    Route::prefix('sub-document')->controller(SubDocumentController::class)->group(function() {
        Route::get('/', 'index')->name('sub-document.index');
        Route::get('/create', 'create')->name('sub-document.create');
        Route::post('/document', 'store')->name('sub-document.store');
        Route::get('/{document}/edit', 'edit')->name('sub-document.edit');
        Route::post('/{document}/update', 'update')->name('sub-document.update');
        Route::get('/{document}', 'show')->name('sub-document.show');
        Route::delete('/destroy/{document}', 'destroy')->name('sub-document.destroy');
    });

    # ----------------------- Rotas - ARQUIVOS ----------------------- #
    Route::prefix('files')->controller(FileController::class)->group(function() {
        Route::get('/', 'index')->name('files.index');
        Route::get('/create', 'create')->name('files.create');
        Route::post('/files', 'store')->name('files.store');
        Route::delete('/destroy/{file}', 'destroy')->name('files.destroy');
    });

    # ----------------------- Rotas - Permissões ----------------------- #
    Route::prefix('permission')->controller(PermissionController::class)->group(function(){
        Route::get('/', 'index')->name('permission.index');
        Route::get('/create', 'create')->name('permission.create');
        Route::post('/permission', 'store')->name('permission.store');
        Route::get('/{permission}/edit', 'edit')->name('permission.edit');
        Route::post('/{permission}/update', 'update')->name('permission.update');
        Route::delete('/destroy/{permission}', 'destroy')->name('permission.destroy');
    });

    Route::prefix('groups')->controller(GroupsController::class)->group(function() {
        Route::get('/', 'index')->name('groups.index');
        Route::get('/create', 'create')->name('groups.create');
        Route::post('/groups', 'store')->name('groups.store');
        Route::get('/{groups}/edit', 'edit')->name('groups.edit');
        Route::post('/{groups}/update', 'update')->name('groups.update');
        // Route::get('/{groups}', 'show')->name('groups.show');
        Route::delete('/destroy/{groups}', 'destroy')->name('groups.destroy');
    });

    # ----------------------- Rotas - Permissões de Grupo ----------------------- #
    Route::prefix('group-permissions')->controller(GroupPermissionController::class)->group(function(){
        Route::get('/create', 'create')->name('group-permissions.create');
        Route::post('/group-permissions', 'store')->name('group-permissions.store');
        Route::get('/{group-permissions}/edit', 'edit')->name('group-permissions.edit');
        Route::post('/{groupPermissions}/update', 'update')->name('group-permissions.update');
        Route::get('/{groupPermissions}', 'show')->name('group-permissions.show');
        Route::delete('/destroy/{groupPermissions}', 'destroy')->name('group-permissions.destroy');
    });

    # ----------------------- Rotas - Atribui Permissão para o Usuario (Permissão Individual) - User Permissions ----------------------- #
    Route::prefix('user-permission.index')->controller(UserPermissionsController::class)->group(function(){
        Route::get('/create', 'create')->name('user-permissions.create');
        Route::post('/user-permissions', 'store')->name('user-permissions.store');
        Route::get('/{permission}', 'show')->name('user-permissions.show');
        Route::delete('/user-permissions/{permission}', 'destroy')->name('user-permissions.destroy');
    });

    # ----------------------- Rotas - Atribuir Permissões de Grupo - User Groups ----------------------- #
    Route::prefix('user-groups.index')->controller(UserGroupsController::class)->group(function(){
        Route::get('/create', 'create')->name('user-groups.create');
        Route::post('/user-groups', 'store')->name('user-groups.store');
        Route::delete('/permission-groups/{permission}', 'destroy')->name('user-groups.destroy');
    });

    # ----------------------- Rotas - Criação de Projetos ----------------------- #
    Route::prefix('projects')->controller(ProjectController::class)->group(function() {
        Route::get('/', 'index')->name('projects.index');
        Route::get('/create', 'create')->name('projects.create');
        Route::post('/projects', 'store')->name('projects.store');
        Route::get('/{projects}/edit', 'edit')->name('projects.edit');
        Route::post('/{projects}/update', 'update')->name('projects.update');
        // Route::get('/{projects}', 'show')->name('projects.show');
        Route::delete('/destroy/{projects}', 'destroy')->name('projects.destroy');

        Route::get('/{projects}/create-pdf', 'createPdf')->name('projects.pdf');
    });
});

# ----------------------- Rota - DOCUMENTAÇÃO ----------------------- #
Route::prefix('view-document')->controller(ViewDocumentController::class)->group(function() {
    Route::get('/project/{projects}', 'index')->name('view-document.index');
    Route::get('/{document}', 'show')->name('view-document.show');
});

