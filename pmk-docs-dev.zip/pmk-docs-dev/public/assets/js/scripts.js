$(document).ready(function()
{
    // Deletar Documento Princiapl Versão
    $('body').on('click','.deleteDocumentVersionBtn', function(e) {
        e.preventDefault();

        const document_version_id = $(this).val();
        const result = document_version_id.split("|");

        $('#document_version_id').val(result[0]);
        $('#document_version_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Documento
    $('body').on('click','.deleteDocumentBtn', function(e) {
        e.preventDefault();

        const document_id = $(this).val();
        const result = document_id.split("|");

        $('#document_id').val(result[0]);
        $('#document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Sub Documento
    $('body').on('click','.deleteSubDocumentBtn', function(e) {
        e.preventDefault();

        const sub_document_id = $(this).val();
        const result = sub_document_id.split("|");

        $('#sub_document_id').val(result[0]);
        $('#sub_document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Tipo de Documento
    $('body').on('click','.deleteTypeBtn', function(e) {
        e.preventDefault();

        const type_id = $(this).val();
        const result = type_id.split("|");

        $('#type_id').val(result[0]);
        $('#type_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Arquivos
    $('body').on('click','.deleteFile', function(e) {
        e.preventDefault();

        const file_delete_id = $(this).val();
        const result = file_delete_id.split("|");

        $('#file_delete_id').val(result[0]);
        $('#file_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Mostrar PDF - Preview
    $('body').on('click', '.preview', function(e) {
        e.preventDefault();

        const image_name = $(this).val();
        const result = image_name.split("|");
        const pdfUrl = result[1];

        $('#pdf-viewer').attr('src', pdfUrl);

        $('#image_name').text(result[0]);
        $('#image_path').attr("src", result[1]);

        $('#previewModal').modal('show');
    });

    $('.close').on('click', function() {
        $('#pdf-viewer').attr('src', '');
    });

    // Copia o código Path de caminho, onde está o arquivo
    $('body').on('click', '.copy', function(e) {
        e.preventDefault();
        const texto = $(this).val();

        navigator.clipboard.writeText(texto)
        .then(() => {
            alert("Texto copiado com Sucesso!");
        })
        .catch(err => {
            alert("Erro ao copiar o texto:", err);
        });
    });

    // Deletar Tipo de Documento
    $('body').on('click','.deleteGroupBtn',function(e) {
        e.preventDefault();

        const group_delete_id = $(this).val();
        const result = group_delete_id.split("|");

        $('#group_delete_id').val(result[0]);
        $('#group_name').text(result[1]);

        $('#deleteModal').modal('show');
    });

    // Deletar permissão - Rota permission.destroy
    $('body').on('click','.deletePermission', function(e) {
        e.preventDefault();

        const permission_delete_id = $(this).val();
        const result = permission_delete_id.split("|");
        const name = result[1] + " " + "-" + " " + result[2];

        $('#permission_delete_id').val(result[0]);
        $('#permission_name').text(name);

        $('#deleteModal').modal('show');
    });

    // Botão Show de Grupos (Permissões)
    $('body').on('click', '.showBtnGroup', function(e){
        e.preventDefault();

        const permission_delete_id = $(this).val();
        const result = permission_delete_id.split("|");
        const name = result[1] + " " + "-" + " " + result[2];

        $('#permission_delete_id').val(result[0]);
        $('#permission_name').text(name);

        $('#deleteModal').modal('show');
    });

    $('body').on('click', '.deletePermissionGroupBtn', function(e) {
        e.preventDefault();

        const permission_group_id = $(this).val();
        const result = permission_group_id.split("|");

        $('#permission_group_id').val(result[0]);
        $('#permission_group_name').text(result[1]);
        $('#deletePermissionGroupModal').modal('show');
    });

    // Deletar Usuarios
    $('body').on('click', '.deleteUser', function(e) {
        e.preventDefault();

        const user_delete_id = $(this).val();
        const result = user_delete_id.split("|");

        $('#user_delete_id').val(result[0]);
        $('#user_name').text(result[1]);
        $('#deleteUser').modal('show');
    });

    $('body').on('click', '.deletePermissionUserInd', function(e) {
        e.preventDefault();

        const permission_user_individual_id = $(this).val();
        const result = permission_user_individual_id.split("|");
        const name = result[1] + " " + "-" + " " + result[2];

        $('#permission_user_individual_id').val(result[0]);
        $('#permission_user_individual_name').text(name);

        $('#deletePermissionUserInd').modal('show');
    });

    $('body').on('click', '.deletePermissionUserGroup', function(e) {
        e.preventDefault();

        const permission_user_group_id = $(this).val();
        const result = permission_user_group_id.split("|");

        $('#permission_user_group_id').val(result[0]);
        $('#permission_user_group_name').text(result[1]);
        $('#deletePermissionUserGroup').modal('show');
    });

    // Deletar Projeto - Rota projects.destroy
    $('body').on('click','.deleteProjects', function(e) {
        e.preventDefault();

        const project_delete_id = $(this).val();
        const result = project_delete_id.split("|");
        const name = result[1];

        $('#project_delete_id').val(result[0]);
        $('#project_name').text(name);

        $('#deleteModal').modal('show');
    });
});

// Obtém o elemento input date
const inputDate = $("#date_document");

// Cria um objeto Date com a data atual
const now = new Date();
const formattedDate = now.getFullYear() + "-" + (now.getMonth() + 1).toString().padStart(2, "0") + "-" + now.getDate().toString().padStart(2, "0");

// Define o valor do campo input date para a data atual
inputDate.val(formattedDate);
