<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // Permissões Individuais
    // public function user_permissions()
    // {
    //     return $this->hasMany(UserPermissions::class, "id_user", "id");
    // }

    public function user_permissions()
    {
        return $this->belongsToMany(Permissions::class, "user_permissions" , "id_user", "id_permission");
    }

    // Permissão de Grupo
    // public function user_groups()
    // {
    //     return $this->hasMany(UserGroups::class, "id_user", "id");
    // }

    public function user_groups()
    {
        return $this->belongsToMany(Groups::class, "user_groups", "id_user", "id_group");
    }
}
