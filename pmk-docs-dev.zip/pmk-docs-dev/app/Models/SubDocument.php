<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubDocument extends Model
{
    use HasFactory;

    protected $table = 'sub_documents';

    protected $fillable = ['id_document_versions', 'type', 'name', 'description', 'date_document'];

    // Um sub documento pode ter somente um tipo
    public function types()
    {
        return $this->hasOne(Type::class, "id", "type");
    }

    // Um sub documento pertence a um documento que possui versão
    public function subDocument()
    {
        return $this->hasOne(DocumentVersion::class, "id", "id_document_versions");
    }
}
