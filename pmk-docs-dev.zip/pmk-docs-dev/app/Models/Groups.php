<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Groups extends Model
{
    use HasFactory;

    protected $table = 'groups';

    protected $fillable = ['name'];

    public function user_groups()
    {
        return $this->hasMany(UserGroups::class, "id_group", "id");
    }

    // public function group_permissions()
    // {
    //     return $this->hasMany(GroupPermissions::class, "id_group", "id");
    // }

    public function group_permissions()
    {
        return $this->belongsToMany(Permissions::class, "group_permissions" ,"id_group", "id_permission");
    }
}
