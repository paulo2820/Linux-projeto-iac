<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    use HasFactory;

    protected $table = 'documents';

    protected $fillable = ['id_document', 'type', 'id_project', 'name'];

    public function types()
    {
        return $this->hasOne(Type::class, "id", "type");
    }

    public function documentVersions()
    {
        return $this->hasMany(DocumentVersion::class, "id_document", "id");
    }

    public function oneDocumentVersion()
    {
        return $this->hasOne(DocumentVersion::class, "id_document", "id")->orderByDesc('version');
    }
}
