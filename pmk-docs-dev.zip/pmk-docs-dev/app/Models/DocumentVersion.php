<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentVersion extends Model
{
    use HasFactory;

    protected $table = 'document_versions';

    protected $fillable = ['id_document', 'version', 'description', 'date_document'];

    public function documents()
    {
        return $this->hasMany(Document::class, "id", "id_document");
    }

    // Uma versão pode ter vários Sub Documentos
    public function subDocuments()
    {
        return $this->hasMany(SubDocument::class, "id_document_versions", "id");
    }
}
