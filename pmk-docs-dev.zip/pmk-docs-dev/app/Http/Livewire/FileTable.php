<?php

namespace App\Http\Livewire;

use App\Models\File;
use Livewire\WithPagination;
use Livewire\Component;
use Illuminate\Support\Str;

class FileTable extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $sortColumn = 'created_at';

    public $sortDirection = 'desc';

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function sortBy($column)
    {
        if($this->sortColumn === $column) {
            $this->sortDirection = $this->swapSortDirection();
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortColumn = $column;
    }

    public function swapSortDirection() {
        return $this->sortDirection === 'asc' ? 'desc' : 'asc';
    }

    public function render(File $file)
    {
        $files = $file->query()
            ->where('name', 'like', '%' . $this->filters['search'] . '%')
            ->orWhere('type', 'like', "%" . $this->filters['search'] . "%")
            ->orderBy($this->sortColumn, $this->sortDirection)
            ->paginate($this->perPage);
        ;

        return view('livewire.file-table')->with('files', $files);
    }
}
