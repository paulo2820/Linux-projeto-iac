<?php

namespace App\Http\Livewire;

use App\Models\Projects;
use Livewire\Component;
use Livewire\WithPagination;
use SebastianBergmann\CodeCoverage\Report\Xml\Project;

class ProjectsTable extends Component
{

    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $sortColumn = 'created_at';

    public $sortDirection = 'asc';

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function sortBy($column)
    {
        if($this->sortColumn === $column) {
            $this->sortDirection = $this->swapSortDirection();
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortColumn = $column;
    }

    public function swapSortDirection() {
        return $this->sortDirection === 'asc' ? 'desc' : 'asc';
    }

    public function render(Projects $project)
    {
        $projects = $project->query()
            ->where('name', 'like', '%' . $this->filters['search'] . '%')
            ->orWhere('description', 'like', "%" . $this->filters['search'] . "%")
            ->orderBy($this->sortColumn, $this->sortDirection)
            ->paginate($this->perPage);
        ;

        return view('livewire.projects-table', compact('projects'));
    }
}
