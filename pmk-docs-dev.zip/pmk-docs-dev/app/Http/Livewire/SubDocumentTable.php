<?php

namespace App\Http\Livewire;

use App\Models\Document;
use App\Models\DocumentVersion;
use App\Models\SubDocument;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class SubDocumentTable extends Component
{
    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $sortColumn = 'date_document';

    public $sortDirection = 'desc';

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function sortBy($column)
    {
        if($this->sortColumn === $column) {
            $this->sortDirection = $this->swapSortDirection();
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortColumn = $column;
    }

    public function swapSortDirection() {
        return $this->sortDirection === 'asc' ? 'desc' : 'asc';
    }

    public function render()
    {
        $documents = Document::join('document_versions', 'documents.id', 'id_document')
            ->join('sub_documents', 'document_versions.id', 'sub_documents.id_document_versions')
            ->where('sub_documents.name', 'like', "%" . $this->filters['search'] . "%")
            ->orWhere('documents.name', 'like', "%" . $this->filters['search'] . "%")
            ->orWhere('document_versions.version', 'like', "%" . $this->filters['search'] . "%")
            ->orderBy($this->sortColumn, $this->sortDirection)
            ->paginate($this->perPage, [
                'documents.name as document_name',
                'document_versions.version',
                'sub_documents.name',
                'sub_documents.id',
                'sub_documents.date_document'
            ]);

        return view('livewire.sub-document-table')->with('documents', $documents);
    }
}
