<?php

namespace App\Http\Livewire;

use App\Models\Permissions;
use App\Models\User;
use App\Models\UserGroups;
use Livewire\Component;
use Livewire\WithPagination;

class PermissionTable extends Component
{

    use WithPagination;

    protected $paginationTheme = 'bootstrap';

    public $sortColumn = 'controller';

    public $sortDirection = 'asc';

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function sortBy($column)
    {
        if($this->sortColumn === $column) {
            $this->sortDirection = $this->swapSortDirection();
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortColumn = $column;
    }

    public function swapSortDirection() {
        return $this->sortDirection === 'asc' ? 'desc' : 'asc';
    }

    public function render(Permissions $permission)
    {
        $permissions = $permission->query()
            ->where('controller', 'like', '%' . $this->filters['search'] . '%')
            ->orWhere('name', 'like', "%" . $this->filters['search'] . "%")
            // ->orWhere('description', 'like', "%" . $this->filters['search'] . "%")
            ->orderBy($this->sortColumn, $this->sortDirection)
            ->paginate($this->perPage);
        ;

        return view('livewire.permission-table',compact('permissions'));
    }
}
