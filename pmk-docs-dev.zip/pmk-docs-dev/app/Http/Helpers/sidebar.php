<?php

use App\Models\Document;
use App\Models\DocumentVersion;
use App\Models\Projects;
use Illuminate\Support\Facades\DB;

function document()
{
    $viewDocuments = Document::query()
        ->with('types', 'documentVersions')
        ->get();
    ;

    return $viewDocuments;
}

// Retorna todos os documentos e sua ultima versão
function allDocuments()
{
    $documents = DocumentVersion::select('id_document', DB::raw('MAX(version) as max_version'))
        ->groupBy('id_document')
        ->get();
    ;

    return $documents;
}

// Retornar todos os Documentos e sua ultima versão de um determinado Projeto
function allDocumentsProject($id_project)
{
    // Ordena do documento mais recente para o mais antigo
    $documents = Document::where('id_project', '=', $id_project)
        ->orderBy('created_at', 'desc')
        ->has('documentVersions')
        ->get()
    ;

    return $documents;
}

?>


