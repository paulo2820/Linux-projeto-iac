<?php

use Illuminate\Validation\Rules\Exists;

# Função que verifica juntamente com a middlaware se existe a permissão para a rota
function verifiedPermission ($controller) {

    # A primeira barra escapa a segunda, array na posição 1 é a action e o 0 controller
    $permissions = explode('\\', $controller['controller']);
    $permissions = explode('@', end($permissions));
    $permissionName = $permissions[1] . "|" . $permissions[0];

    $permissions = session('permissions', []);

    // dd($permissions);

    if (in_array($permissionName, $permissions)) {
       return true;
    } else {
        return false;
    }
}

# Função que verifica se existe na session as permissions
function verifiedUserPermission($permission) {

    $permissions = session('permissions', []);

    // dd($permissions);
    // if (in_array($permissions, $permission)) {
    //     return true;
    // } else {
    //     return false;
    // }

    # Pesquisa a string estatica do template
    if (array_search($permission, $permissions)) {
        return true;
    } else {
        return false;
    }
}
