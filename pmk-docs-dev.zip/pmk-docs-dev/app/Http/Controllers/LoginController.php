<?php

namespace App\Http\Controllers;

use App\Models\Groups;
use App\Models\UserPermissions;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('auth.login', compact('mensagemSucesso'));
    }

    public function login(Request $request)
    {
        // Credenciais para o momento de Login
        $credentials = $request->validate(
            [
                'email' => ['required','exists:users,email'],
                'password' => ['required'],
            ],
            [
                'email.required' => 'Necessário informar um Email!',
                'email.exists' => 'Email inválido!',
                'password.required' => 'Necessário informar uma Senha!'
            ]
        );

        # Verifica o Login e se o usuário possui alguma permissão e cria uma session com as permissões!
        if (auth()->attempt($credentials)) {
            $user = Auth::user();

            $permissions = [
                'index|DashboardController',
            ];

            # Retorna as permissões de grupo - Caso exista
            if ($user->user_groups->isNotEmpty()) {
                foreach ($user->user_groups as $user_groups) {
                    foreach ($user_groups->group_permissions as $group_permission) {
                        $permissions[] = $group_permission['name']."|".$group_permission['controller'];
                    }
                }
            }

            # Retorna as permissões individuais - Caso exista
            if ($user->user_permissions->isNotEmpty()) {
                foreach ($user->user_permissions as $user_permission) {
                    if (!in_array($user_permission['name'] . "|" . $user_permission['controller'], $permissions)) {
                        $permissions[] = $user_permission['name'] . "|" . $user_permission['controller'];
                    }
                }
            }

            # Voltando o array vazio o usário não possui permissão
            if (empty($permissions)) {
                abort(403);
            }

            $request->session()->put('permissions', $permissions);

            $request->session()->regenerate();

            // dd($request->session());

            return redirect(route('dashboard'));
        }

        # Caso exista um erro na validação, exibe as seguintes mensagens
        return back()->withErrors([
            'email' => 'Email inválido!',
            'password' => 'Senha inválida!',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        // Logout do usuário logado
        Auth::logout();

        // Sessão fica invalidada
        $request->session()->invalidate();

        // Regenero um novo token
        $request->session()->regenerateToken();

        return redirect(route('login'));
    }
}
