<?php

namespace App\Http\Controllers;

use App\Models\Document;
use App\Models\DocumentVersion;

class ViewDocumentController extends Controller
{
    public function index($projects)
    {
        return view('document-view.index', compact('projects'));
    }

    public function show(Document $document)
    {
        $projects = $document->id_project;

        return view('document-view.show', compact('document', 'projects'));
    }
}
