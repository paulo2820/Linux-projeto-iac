<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Projects;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('projects.index', compact('mensagemSucesso'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('projects.create', compact('mensagemSucesso'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Projects $project)
    {
        $validator = Validator::make($request->all(),
        [
            'name' => ['required','max:40', 'unique:projects'],
            'description' =>['required','max:400', 'unique:projects,description'],
        ],

        [
            'name.required' => 'Necessário informar o Nome do projeto!',
            'name.unique' => 'Este projeto já existe!',
            'description.required' => 'Necessário informar uma descrição!',
            'description.unique' => 'Está descrição já existe!'
        ]
    );

    if ($validator->fails()) {
        return redirect(route('projects.create'))
            ->withErrors($validator)
            ->withInput();
    }

    $projects = $project->create($request->all());

    return redirect(route('projects.create'))
        ->with('mensagem.sucesso', "Projeto '{$projects->name}' cadastrado com sucesso!");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Projects $projects)
    {
        // return view('projects.show', compact('projects'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Projects $projects)
    {
        // dd($projects);
        return view('projects.edit', compact('projects'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Projects $projects, Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'name' => ['required', 'max:40', Rule::unique('projects')->ignore($projects->id)],
            'description' => ['required']
        ],
        [
            'name.required' => 'É necessário informar o nome do projeto!',
            'name.unique' => 'Este nome de projeto já existe!',
            'name.max' => 'O nome do projeto pode ter apenas :max caracteres',
            'description.required' => 'Necessário uma descrição para o projeto!',
        ]
    );

    if ($validator->fails()) {
        return redirect(route('projects.edit', $projects->id))
            ->withErrors($validator)
            ->withInput();
    }

    $projects->name = $request->name;
    $projects->description = $request->description;
    $projects->save();

    return redirect(route('projects.index'))
        ->with('mensagem.sucesso', "Projeto '{$projects->name}' atualizado com sucesso!");
    }

    public function destroy(Request $request)
    {
        $project = Projects::find($request->project_delete_id);

        $project->delete();

        return redirect(route('projects.index'))
            ->with('mensagem.sucesso', "Projeto '{$project->name}' deletado com sucesso!");
    }

    public function createPdf(Projects $projects)
    {
        $nameProject = "<h1>" . "Projeto" . " " . $projects->name . "</h1>";
        $descriptionProject = "<p>" . $projects->description . "</p>";
        $dataCreated = "<i>" . "Data de criação:" . " " . date_format($projects->created_at, "d/m/Y") . "</i><br>";

        $htmlPdf = [];

        array_push($htmlPdf, $nameProject, $dataCreated, $descriptionProject);

        foreach ($projects->documents as $document) {

            foreach ($document->documentVersions as $documentVersion) {
                array_push(
                    $htmlPdf,
                    "<h1>" . $document->name . " " . $documentVersion->version . " " . $document->types->name . "</h1><hr>",
                    "<i>" . "Data de criação:" . " " . date_format($documentVersion->created_at, "d/m/Y") . "</i><br>",
                    "<p>" . $documentVersion->description . "</p><br>"
                );

                foreach ($documentVersion->subDocuments as $subDocument) {
                    // dd($subDocument);
                    array_push(
                        $htmlPdf,
                        "<h3>" . "#" . " " . $subDocument->name . " " . $subDocument->types->name . "</h3>",
                        "<i>" . "Data de criação:" . " " . date_format($subDocument->created_at, "d/m/Y") . "</i>",
                        "<p>" . $subDocument->description . "</p><br>"
                    );
                }
            }
        }

        $pdf_name = $projects->name . ".pdf";

        $pdfPronto = implode('', $htmlPdf);

        $pdf = App::make('dompdf.wrapper');

        $pdf->setOption([
            'defaultPaperSize' => 'a4',
        ]);

        $pdf->loadHTML($pdfPronto);

        return $pdf->stream("Projeto $pdf_name");
    }
}
