<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\Projects;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class DocumentController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        $documents = Document::with("types")
            ->orderBy('name')
            ->get()
        ;

        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        $projects = Projects::select('*')
            ->orderBy('name')
            -> get()
        ;

        $mensagemSucesso = session('mensagem.sucesso');

        return view('document.create',compact('documents', 'types', 'projects' ,'mensagemSucesso'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => ['required','max:40', 'unique:documents'],
                'type' => ['required'],
                'id_project' => ['required']
            ],
            [
                'name.required' => 'Necessário informar o Nome do Documento!',
                'name.max' => 'Quantidade de caracteres Inválido!',
                'name.unique' => 'O Documento informado já existe!',
                'type.required' => 'Necessário informar o Tipo do Documento!',
                'id_project.required' => 'Necessário informar o nome do Projeto!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('document.create'))
                ->withErrors($validator)
                ->withInput();
        }

        // Criando Documento na tabela documents
        $document = Document::create($request->all());

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Documento '{$document->name}' cadastrado com sucesso!");
    }

    public function show(Document $document)
    {
        //
    }

    public function edit(Document $document)
    {
        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        $projects = Projects::select('*')
            ->orderBy('name')
            ->get()
        ;

        return view('document.edit', compact('document', 'types', 'projects'));
    }

    public function update(Document $document, Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => ['required','max:40', Rule::unique('documents')->ignore($document->id)],
                'type' => ['required'],
                'id_project' => ['required']
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'name.max' => 'Quantidade de caracteres Inválido!',
                'name.unique' => 'O tipo de Documento informado já existe!',
                'type.required' => 'Necessário informar o Tipo do Documento!',
                'id_project.required' => 'Necessário informar o projeto!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('document.edit', $document->id))
                ->withErrors($validator)
                ->withInput();
        }


        $document->name = $request->name;
        $document->type = $request->type;
        $document->id_project = $request->id_project;
        $document->save();

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Documento '{$document->name}' atualizado com sucesso!");
    }

    public function destroy (Request $request)
    {
        $document = Document::find($request->document_delete_id);

        if(isset($document)) {
            $document->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Documente deletado com sucesso!');

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Usuário '{$document->name}' removido do sistema com sucesso!");
    }
}
