<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permissions;
use App\Models\User;
use App\Models\UserGroups;
use App\Models\UserPermissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserPermissionsController extends Controller
{
    public function create(User $user, Permissions $permission)
    {
        $users = $user->select('id', 'name')
            ->get()
        ;

        $permissions = $permission->select('id', 'name', 'controller')
            ->get()
        ;

        return view('user-permissions.create', compact('users', 'permissions'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'id_user' => ['required'],
                'permission' => ['required'],
            ],
            [
                'id_user.required' => 'Necessário informar um Usuário!',
                'permission.required' => 'Necessário informar pelo menos uma Permissão!',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('user-permissions.create'))
                ->withErrors($validator)
                ->withInput();
        }

        foreach ($request->permission as $key => $id) {

            $insert = [
                'id_user' => $request->id_user,
                'id_permission' => $request->permission[$key],
            ];

            UserPermissions::firstOrCreate($insert);
        }

        return redirect(route('users.index'))
            ->with('mensagem.sucesso', "Permissões cadastrado com Sucesso!");
    }

    public function show(User $permission)
    {
        $permissions = $permission->join('user_permissions', 'users.id', '=', 'user_permissions.id_user')
            ->join('permissions', 'permissions.id', '=', 'user_permissions.id_permission')
            ->select('user_permissions.id', 'permissions.name', 'permissions.controller', 'permissions.description')
            ->where('users.id', '=', $permission->id)
            ->get();

        $permissionGroup = $permission->join('user_groups', 'users.id', '=', 'user_groups.id_user')
            ->join('groups', 'user_groups.id_group', '=', 'groups.id')
            ->select('user_groups.id','groups.name')
            ->where('user_groups.id_user', '=', $permission->id)
            ->get()
        ;

        // dd($permissionGroup);

        return view('user-permissions.show', compact('permission', 'permissions', 'permissionGroup'));
    }

    public function destroy(Request $request)
    {
        switch ($request) {
            case isset($request->permission_user_individual_id):
                $permission = UserPermissions::find($request->permission_user_individual_id);

                if(isset($permission)) {
                $permission->delete();
            }

            case isset($request->permission_user_group_id):
                $permissionGroup = UserGroups::find($request->permission_user_group_id);

            if(isset($permissionGroup)) {
                $permissionGroup->delete();
            }
        }

        $request->session()->flash('mensagem.sucesso', 'Permissão deletada com Sucesso!');

        return redirect(route('users.index'))
            ->with('mensagem.sucesso', "Permissão removida do sistema com sucesso!");
    }
}
