<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Groups;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class GroupsController extends Controller
{
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('groups.index', compact('mensagemSucesso'));
    }

    public function create(Groups $group)
    {
        $groups = $group->select('*')
            ->get()
        ;

        $mensagemSucesso = session('mensagem.sucesso');

        return view('groups.create', compact('groups', 'mensagemSucesso'));
    }

    public function store(Groups $group, Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => ['required','max:40', 'unique:groups'],
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'name.unique' => 'Nome de grupo existente!',
                'name.max' => 'Quantidade de caracteres Inválido!',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('groups.create'))
                ->withErrors($validator)
                ->withInput();
        }

        $groups = $group->create($request->all());

        return redirect(route('groups.index'))
            ->with('mensagem.sucesso', "Grupo '$groups->name' Cadastrado com sucesso!");
    }

    public function show(Groups $groups)
    {
        //
    }

    public function edit(Groups $groups)
    {
        return view('groups.edit', compact('groups'));
    }

    public function update(Groups $groups,Request $request)
    {
        // dd($request->all());
        $validator = Validator::make($request->all(),
            [
                'name' => ['required', Rule::unique('groups')->ignore($groups->id)],
            ],
            [
                'name.required' => 'Necessário informar um Nome para o Grupo!',
                'name.unique' => 'Nome de Grupo informado já existe!',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('groups.edit', $groups->id))
                ->withErrors($validator)
                ->withInput();
        }

        $groups->name = $request->name;
        $groups->save();

        return redirect(route('groups.index'))
            ->with('mensagem.sucesso', "Nome '{$groups->name}' atualizado com Sucesso!");
    }

    public function destroy(Request $request)
    {
        $group = Groups::find($request->group_delete_id);

        if(isset($group)) {
            $group->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Grupo deletado com sucesso!');

        return redirect(route('groups.index'))
            ->with('mensagem.sucesso', "Grupo '$group->name' removido com sucesso!");
    }
}
