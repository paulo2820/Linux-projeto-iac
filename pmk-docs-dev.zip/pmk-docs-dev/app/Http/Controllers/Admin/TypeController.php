<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\TypeRequest;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class TypeController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        $mensagemSucesso = session('mensagem.sucesso');

        return view('type.create', compact('types', 'mensagemSucesso'));
    }

    // public function store(TypeRequest $request)
    // {
    //     $type = Type::create($request->all());

    //     return redirect(route('type.create'))
    //         ->with('mensagem.sucesso', "Tipo de Documento '{$type->name}' cadastrado com sucesso!");
    // }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => 'required|max:20|unique:types',
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'name.max' => 'Quantidade de caracteres Inválido!',
                'name.unique' => 'O tipo de Documento informado já existe!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('type.create'))
                ->withErrors($validator)
                ->withInput();
        }

        $type = Type::create($request->all());

        return redirect(route('type.create'))
            ->with('mensagem.sucesso', "Tipo de Documento '{$type->name}' cadastrado com sucesso!");
    }

    public function show($id)
    {
        //
    }

    public function edit(Type $type)
    {
        return view('type.edit', compact('type'));
    }

    public function update(Type $type, Request $request)
    {

        $validator = Validator::make($request->all(),
            [
                'name' => ['required','max:20', Rule::unique('types')->ignore($type->id)],
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'name.max' => 'Quantidade de caracteres Inválido!',
                'name.unique' => 'O tipo de Documento informado já existe!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('type.edit', $type->id))
                ->withErrors($validator)
                ->withInput();
        }

        $type->name = $request->name;
        $type->save();

        return redirect(route('type.create'))
            ->with('mensagem.sucesso', "Tipo de Documento '{$type->name}' atualizado com sucesso!");
    }

    public function destroy(Request $request)
    {
        $type = Type::find($request->type_delete_id);

        if (isset($type)) {
            $type->delete();
        } else {
            $request->session()->flash('mensagem.sucesso', 'Tipo de Documento não existe!');
        }

        return redirect(route('type.create'))
            ->with('mensagem.sucesso', "Tipo de Documento '{$type->name}' removido com sucesso!");
    }
}
