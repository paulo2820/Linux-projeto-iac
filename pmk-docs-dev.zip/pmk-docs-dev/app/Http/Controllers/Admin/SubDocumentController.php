<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SubDocumentRequest;
use App\Models\Document;
use App\Models\SubDocument;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SubDocumentController extends Controller
{
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('sub-document.index', compact('mensagemSucesso'));
    }

    public function create()
    {
        // Tras os tipos para cadastro
        $types = Type::all();

        // Tras os documentos principais para cadastrar no id_document
        // Enquanto não houver um Documento com versão não tem como criar um sub documento
        $documents = Document::select('*')
            ->with('types', 'documentVersions')
            ->orderBy('name')
            ->get()
        ;

        $mensagemSucesso = session('mensagem.sucesso');

        return view('sub-document.create',compact('types' , 'documents', 'mensagemSucesso'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => 'required|max:40',
                'id_document_versions' => ['required'],
                'type' => ['required'],
                'description' => ['required']
            ],
            [
                'name.required' => 'É necessário informar um nome!',
                'name.max' => 'O nome do Cliente pode ter apenas :max caracteres',
                'id_document_versions.required' => 'Necessário informar para qual Documento Principal!',
                'type.required' => 'Necessário Informar o tipo do Sub Documento!',
                'description.required' => 'Necessário uma Descrição para o Sub Documento',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('sub-document.create'))
                ->withErrors($validator)
                ->withInput();
        }

        $document = SubDocument::create($request->all());

        return redirect(route('sub-document.index'))
            ->with('mensagem.sucesso', "Sub Documento '{$document->name}' cadastrado com sucesso!");
    }


    // public function show(SubDocument $document)
    // {
    //     $documents = SubDocument::with("types")->get();

    //     return view('document-view.index', compact('document', 'documents'));
    // }

    public function edit(SubDocument $document)
    {
        // dd($document);

        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        $documents = Document::select('*')
            ->with('types', 'documentVersions')
            ->orderBy('name')
            ->get()
        ;

        return view('sub-document.edit', compact('document', 'types', 'documents'));
    }

    public function update(SubDocument $document, Request $request)
    {

        $validator = Validator::make($request->all(),
            [
                'name' => 'required|max:40',
                'id_document_versions' => ['required'],
                'type' => ['required'],
                'description' => ['required']
            ],
            [
                'name.required' => 'É necessário informar um nome!',
                'name.max' => 'O nome do Cliente pode ter apenas :max caracteres',
                'id_document_versions.required' => 'Necessário informar para qual Documento Principal!',
                'type.required' => 'Necessário Informar o tipo do Sub Documento!',
                'description.required' => 'Necessário uma Descrição para o Sub Documento',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('sub-document.edit', $document->id))
                ->withErrors($validator)
                ->withInput();
        }

        $document->name = $request->name;
        $document->type = $request->type;
        $document->id_document_versions = $request->id_document_versions;
        $document->description = $request->description;
        $document->save();

        return redirect(route('sub-document.index'))
            ->with('mensagem.sucesso', "Sub Documento '{$document->name}' atualizado com sucesso!");
    }

    public function destroy (Request $request)
    {
        $document = SubDocument::find($request->sub_document_delete_id);

        if(isset($document)) {
            $document->delete();
        } else {
            $request->session()->flash('mensagem.sucesso', 'Documento não existe!');
        }

        return redirect(route('sub-document.index'))
            ->with('mensagem.sucesso', "Sub Documento '{$document->name}' removido com sucesso!");
    }
}
