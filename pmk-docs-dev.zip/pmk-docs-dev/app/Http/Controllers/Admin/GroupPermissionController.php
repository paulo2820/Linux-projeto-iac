<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GroupPermissions;
use App\Models\Groups;
use App\Models\Permissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class GroupPermissionController extends Controller
{
    public function index()
    {
        //
    }

    public function create(Groups $group, Permissions $permission)
    {
        $mensagemSucesso = session('mensagem.sucesso');

        $groups = $group->select('*')
            ->get();

        $permissions = $permission->select('*')
            ->get();

        // $mensagemSucesso = session('mensagem.sucesso');

        return view('group-permissions.create', compact('groups', 'permissions', 'mensagemSucesso'));
    }

    public function store(Request $request)
    {
        // dd($request->all());
        $validator = Validator::make($request->all(),
            [
                'id_group' => ['required', Rule::unique('group_permissions')
                    ->where(function ($query) use ($request) {
                        return $query->where('id_permission', $request->input('permission'));
                    }),
                ],
                'permission' => ['required'],
            ],
            [
                'id_group.required' => 'Necessário informar um Grupo!',
                'id_group.unique' => 'Pelo menos uma das permissões já está cadastrada!',
                'permission.required' => 'Necessário informar pelo menos uma Permissão!',
            ]
        );



        if ($validator->fails()) {
            return redirect(route('group-permissions.create'))
                ->withErrors($validator)
                ->withInput();
        }

        foreach ($request->permission as $key =>$value) {
            $insert = [
                'id_group' => $request->id_group,
                'id_permission' => $request->permission[$key],
            ];

            // GroupPermissions::insert($insert);

            // Sempre ira atualizar ou criar, se existir ele da update se nao existir ele vai criar
            GroupPermissions::firstOrCreate($insert);

        }

        return redirect(route('group-permissions.create'))
            ->with('mensagem.sucesso', "Permissões cadastradas com Sucesso!");
    }

    public function show(Groups $groupPermissions)
    {
        // dd($groupPermissions->group_permissions);
        $permissions = $groupPermissions->join('group_permissions', 'groups.id', '=', 'group_permissions.id_group')
            ->join('permissions', 'permissions.id', '=', 'group_permissions.id_permission')
            ->select('group_permissions.id', 'permissions.name', 'permissions.controller', 'permissions.description')
            ->where('groups.id', '=', $groupPermissions->id)
            ->get()
        ;

        // dd($permissions);

        return view('group-permissions.show', compact('groupPermissions', 'permissions'));
    }

    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        //
    }

    public function destroy(Request $request)
    {
        $group_permissions = GroupPermissions::find($request->permission_group_delete_id);

        if(isset($group_permissions)) {
            $group_permissions->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Permissão Exlcuida com Sucesso!');

        return redirect(route('groups.index'))
            ->with('mensagem.sucesso', "Permissão excluida!");
    }
}
