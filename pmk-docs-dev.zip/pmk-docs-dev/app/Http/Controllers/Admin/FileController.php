<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Middleware\Login;
use App\Models\File;
use Illuminate\Http\Request;

class FileController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware(Login::class);
    // }

    public function index()
    {
        $mensagem = session('mensagem');

        return view('files.index', compact('mensagem'));
    }

    public function create()
    {
        $mensagem = session('mensagem');

        return view('files.create')->with('mensagem', $mensagem);
    }

    public function store(Request $request)
    {
        $request->validate(
            [
                'file' => 'required|mimetypes:image/png,image/jpg,image/jpeg,video/avi,video/mpeg,video/mp4,application/pdf,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ],
            [
                'file.required' => 'Necessário fazer upload de algum arquivo!',
                'file.mimetypes' => 'O tipo de arquivo selecionado é inválido!',
                'file.max' =>'Tamanho do arquivo inválido!',
            ]
        );

        try {
            // Seleciona o nome e o tupo do arquivo
            $fileName = $request->file->getClientOriginalName();
            $fileType = $request->file->getmimeType();

            // Formata o Nome retirando o type no final, exemplo: .pdf
            $name = explode('.' , $fileName);
            $removeType = array_slice($name, 0, -1);
            $name = implode('.', $removeType);

            // Verifica se o nome do arquivo existe no Banco de Dados
            if (File::where('name', 'LIKE', $name)->exists()){
                return redirect()->back()->with('mensagem.error','Este arquivo já existe no Sistema!');
            }

            // Formata o type do arquivo, exemplo: Application/pdf
            $type = explode('/' , $fileType);

            // Caso seja application a primeira posição alterar para PDF
            if ($type[0] == 'application') {
                $type[0] = 'pdf';
            }

            // Insere o Documento
            $path = $request->file('file')->store('files', 'public');

            File::create([
                'type' => "$type[0]",
                'name' => "$name",
                'path' => "/storage/{$path}"
            ]);

            return redirect()->back()->with('mensagem.sucess','Upload do Arquivo feito com sucesso!');

        } catch (\Exception $e) {
            return redirect()->back()->with('mensagem.error','Não foi possivel fazer upload do arquivo!');
        }
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy(File $files, Request $request)
    {
        $file = $files->find($request->file_delete_id);

        // Busca o nome do File
        $name = $file->select()
            ->where('id', $file->id)
            ->pluck('name');

        $file->delete();

        return redirect(route('files.index'))
            ->with('mensagem.sucess', "Arquivo '{$name[0]}' Deletado com Sucesso!");
    }
}
