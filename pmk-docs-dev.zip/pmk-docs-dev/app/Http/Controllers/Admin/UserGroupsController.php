<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Groups;
use App\Models\User;
use App\Models\UserGroups;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserGroupsController extends Controller
{
    public function create(User $user, Groups $group)
    {
        $mensagemSucesso = session('mensagem.sucesso');

        $users = $user->select('id', 'name')
            ->get()
        ;

        $groups = $group->select('id', 'name')
            ->get()
        ;

        return view('user-groups.create', compact('users', 'groups', 'mensagemSucesso'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'id_user' => ['required'],
                'group' => ['required'],
            ],
            [
                'id_user.required' => 'Necessário informar um Grupo!',
                'group.required' => 'Necessário informar pelo menos uma Permissão!',
            ]
        );

        if ($validator->fails()) {
            return redirect(route('user-groups.create'))
                ->withErrors($validator)
                ->withInput();
        }

        foreach ($request->group as $key => $id) {

            $insert = [
                'id_user' => $request->id_user,
                'id_group' => $request->group[$key],
            ];

            UserGroups::firstOrCreate($insert);
        }

        return redirect(route('user-groups.create'))
            ->with('mensagem.sucesso', "Permissões cadastrado com Sucesso!");
    }

    public function destroy(Request $request)
    {
        $groupPermission = UserGroups::find($request->permission_group_delete_id);

        if(isset($groupPermission)) {
            $groupPermission->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Permissão de Grupo deletada com Sucesso!');

        return redirect(route('view-permissions.index'))
            ->with('mensagem.sucesso', "Permissão de Grupo removida do sistema com sucesso!");
    }
}
