<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Groups;
use App\Models\Permissions;
use App\Models\User;
use App\Models\UserPermissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class PermissionController extends Controller
{
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('permission.index', compact('mensagemSucesso'));
    }

    public function create()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('permission.create', compact('mensagemSucesso'));
    }

    public function store(Request $request, Permissions $permission)
    {
        //Name pode existir igual o Cotroller não
        $validator = Validator::make($request->all(),
            [
                'name' => ['required', Rule::unique('permissions')->where(function ($query) use ($request){
                        return $query->where('controller', $request->input('controller'));
                    }),
                ],
                'controller' =>['required'],
                'description' =>['required','max:200', 'unique:permissions,description'],
            ],

            [
                'name.required' => 'Necessário informar o Método!',
                'name.unique' => 'Está permissão já existe!',
                'controller.required' => 'Necessário informar o controller!',
                'controller.unique' => 'Controller informado já existe!',
                'description.required' => 'Necessário informar uma descrição!',
                'description.unique' => 'Está descrição já existe!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('permission.create'))
                ->withErrors($validator)
                ->withInput();
        }

        $permissions = $permission->create($request->all());

        return redirect(route('permission.create'))
            ->with('mensagem.sucesso', "Permissão Individual '{$permissions->name}' cadastrado com sucesso!");
    }

    public function edit(Permissions $permission)
    {
        return view('permission.edit', compact('permission'));
    }

    public function update(Permissions $permission, Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'name' => ['required', Rule::unique('permissions')
                        ->ignore($permission->id)
                        ->where(function ($query) use ($request){
                            return $query->where('controller', $request->input('controller'));
                    }),
                ],
                'controller' =>['required'],
                'description' =>['required','max:200'],
            ],
            [
                'name.required' => 'Necessário informar o Método!',
                'name.unique' => 'Não foi possivel atualizar pois a permissão que foi informada já existe!',
                'controller.required' => 'Necessário informar o controller!',
                'description.required' => 'Necessário informar uma descrição!',
                'description.unique' => 'Já existe uma descrição dessa!'
            ]
        );

        if ($validator->fails()) {
            return redirect(route('permission.edit', ['permission' => $permission->id]))
                ->withErrors($validator)
                ->withInput();
        }

        $permission->name = $request->name;
        $permission->controller = $request->controller;
        $permission->description = $request->description;
        $permission->save();

        return redirect(route('permission.index'))
            ->with('mensagem.sucesso', "Permissão '{$permission->controller}-{$permission->name} 'atualizada com Sucesso!");
    }

    public function destroy (Request $request)
    {
        $permission = Permissions::find($request->permission_delete_id);

        if(isset($permission)) {
            $permission->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Permissão deletado com sucesso!');

        return redirect(route('permission.index'))
            ->with('mensagem.sucesso', "Permissão '{$permission->controller}-{$permission->name}' deletado com sucesso!");
    }
}
