<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UsersController extends Controller
{
    public function index()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('users.index', compact('mensagemSucesso'));
    }

    public function create()
    {
        $mensagemSucesso = session('mensagem.sucesso');

        return view('users.create', compact('mensagemSucesso'));
    }

    public function store(Request $request, LoginController $login)
    {

        $validatorRequest = $request->validate(
            [
                'name' => ['required', 'min:3', 'max:50'],
                'email' => ['required', 'email', 'unique:users,email'],
                'password' => ['required', 'min:6', 'max:12', 'confirmed'],
                'password_confirmation' => ['required'],
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'email.required' => 'Necessário um email válido!',
                'email.unique' => 'Este email já está em uso!',
                'password.required' => 'Necessário informar uma senha!',
                'password.confirmed' => 'Senhas incompativéis!',
                'password_confirmation.required' => 'Necessário confirmação da senha!'
            ]
        );

        $validatorRequest['password'] = Hash::make($validatorRequest['password']);

        $user = User::create($validatorRequest);

        return redirect(route('login'))
            ->with('mensagem.sucesso', "Usuário $user->name cadastrado com Sucesso!");
        // dd($user);

        // return $login->login($user);
    }

    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    public function update(User $user, Request $request)
    {
        $validatorRequest = $request->validate(
            [
                'name' => ['required', 'min:3', 'max:50', Rule::unique('users')->ignore($user->id)],
                'email' => ['required', 'email', Rule::unique('users')->ignore($user->id)],
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'name.unique' => 'Este nome já está em uso!',
                'email.required' => 'Necessário um email válido!',
                'email.unique' => 'Este email já está em uso!',
            ]
        );

        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();

        return redirect(route('users.index'))
            ->with('mensagem.sucesso', "Permissão '{$user->name}' atualizada com Sucesso!");
    }

    public function destroy(Request $request)
    {
        $user = User::find($request->user_delete_id);

        if(isset($user)) {
            $user->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Usuário deletado com sucesso!');

        return redirect(route('users.index'))
            ->with('mensagem.sucesso', "Usuário '{$user->name}' removido com sucesso!");
    }
}
