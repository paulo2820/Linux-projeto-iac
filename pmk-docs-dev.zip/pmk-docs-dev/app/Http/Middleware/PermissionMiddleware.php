<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class PermissionMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        # Pego a action da propria rota ou seja o caminho do Controller, case sensitive, pegar o nome no arquivo Web da action (rota);
        $controller = $request->route()->getAction();

        # Helper que verifica se existe permissão ou não para a rota
        if (verifiedPermission($controller) == true) {
            return $next($request);
        }
        else {
            return abort(403);
        }
    }
}
