<?php

namespace Database\Seeders;

use App\Models\Permissions;
use App\Models\UserPermissions;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissionIds = Permissions::pluck('id');

        // Cria um registro em user_permissions para cada id de permission
        foreach ($permissionIds as $permissionId) {
            UserPermissions::create([
                'id_user' => 1,
                'id_permission' => $permissionId
            ]);
        }
    }


        // array_walk($permissions, function ($permission) use ($actionsCrud) {
        //     array_walk($actionsCrud, function ($action) use ($permission) {
        //         $permissionUpdate['name'] = $action;
        //         $permissionUpdate['controller'] = $permission;
        //         Permissions::updateOrCreate($permissionUpdate);
        //     });
        // });

}
