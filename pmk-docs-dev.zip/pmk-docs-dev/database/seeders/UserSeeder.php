<?php

namespace Database\Seeders;

use App\Models\Groups;
use App\Models\User;
use App\Models\UserGroups;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                ['email' => 'nicolas@pmk.com.br'],
                [
                    'name' => 'Nicolas Ruan',
                    'password' => bcrypt('admin'),
                ]
            ],
            [
                ['email' => 'leonardo.santos@pmk.com.br'],
                [
                    'name' => 'Leonardo Santos',
                    'password' => bcrypt('admin'),
                ]
            ],
            [
                ['email' => 'tiago.batista@pmk.com.br'],
                [
                    'name' => 'Tiago Batista',
                    'password' => bcrypt('admin'),
                ]
            ],
            [
                ['email' => 'paulo.cezar@pmk.com.br'],
                [
                    'name' => 'Paulo Cezar',
                    'password' => bcrypt('admin'),
                ]
            ],
            [
                ['email' => 'lucas.ribeiro@pmk.com.br'],
                [
                    'name' => 'Lucas Ribeiro',
                    'password' => bcrypt('admin'),
                ]
            ],
        ];

        array_walk($users, function($user) {
            $user = User::firstOrCreate($user[0], $user[1]);
        });
    }
}
