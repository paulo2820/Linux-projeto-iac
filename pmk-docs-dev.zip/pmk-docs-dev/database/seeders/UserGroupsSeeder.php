<?php

namespace Database\Seeders;

use App\Models\Groups;
use App\Models\User;
use App\Models\UserGroups;
use Illuminate\Database\Seeder;

class UserGroupsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = User::select('id')->orderBy('id','asc')->get();
        $group = Groups::select('id')->first();

        // Para cada usuário pegar seu id e inserir no id_user, para cada grupo pegar seu id e inserir no id_group
        foreach ( $users as $user) {
            UserGroups::create([
                'id_user' => $user->id,
                'id_group' => $group->id
            ],);
        }
    }
}
