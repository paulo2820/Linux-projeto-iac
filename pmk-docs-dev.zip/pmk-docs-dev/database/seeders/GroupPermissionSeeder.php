<?php

namespace Database\Seeders;

use App\Models\GroupPermissions;
use App\Models\Groups;
use App\Models\Permissions;
use Illuminate\Database\Seeder;

class GroupPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $permissionAll = Permissions::get('id')->toArray();
        // $groupTi = Groups::where('name', 'TI')->get('id')->first()->toArray();

        // array_walk($permissionAll, function ($permissionAll) use($groupTi) {

        //     $permissionAll = [
        //         'id_permission' => $permissionAll['id'],
        //         'id_group' => $groupTi['id'],
        //     ];

        //     GroupPermissions::updateOrCreate($permissionAll);
        // });

        $permissionAll = Permissions::get('id');
        $groupTi = Groups::where('name', 'TI')->first('id');

        foreach ($permissionAll as $permission) {
            GroupPermissions::create([
                'id_group' => $groupTi->id,
                'id_permission' => $permission->id,
            ]);
        }

    }
}
