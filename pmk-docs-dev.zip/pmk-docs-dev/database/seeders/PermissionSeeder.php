<?php

namespace Database\Seeders;

use App\Models\Permissions;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $actionsCrud = [
            'index', 'edit', 'store', 'update', 'create', 'destroy', 'show'
        ];

        $permissions = [
            'DocumentController',
            'DocumentVersionController',
            'FileController',
            'GroupPermissionController',
            'GroupsController',
            'PermissionController',
            'SubDocumentController',
            'TypeController',
            'UserGroupsController',
            'UserPermissionsController',
            'ViewPermissionsController',
            'UsersController',
            'ViewDocumentController',
            'ProjectController',
        ];

        array_walk($permissions, function ($permission) use ($actionsCrud) {
            array_walk($actionsCrud, function ($action) use ($permission) {
                $permissionUpdate['name'] = $action;
                $permissionUpdate['controller'] = $permission;
                Permissions::updateOrCreate($permissionUpdate);
            });
        });

        $otherActions = [
            'editDuplicate', 'storeDuplicate', 'createPdf',
        ];

        $otherPermissions = [
            'DocumentVersionController'
        ];

        array_walk($otherPermissions, function ($otherPermission) use ($otherActions) {
            array_walk($otherActions, function ($otherAction) use ($otherPermission) {
                $otherPermissionsUpd['name'] = $otherAction;
                $otherPermissionsUpd['controller'] = $otherPermission;
                Permissions::updateOrCreate($otherPermissionsUpd);
            });
        });

        Permissions::updateOrCreate(
            [
                'name' => 'createPdf',
                'controller' => 'ProjectController',
            ]
        );
    }
}
